# 0.3.27 전체 학기의 본인 과제 제출 이력 읽기

`LearningxClient.assignmentSubmissionHistory(courseId, assignmentId, signal?)`는 전체 학기의 본인 수강권한을 새로 확인한 뒤 학교가 반환한 이전 제출 시도를 읽는다. 0.3.26에서 추가한 이력 계약에 0.3.27의 과거 학기 읽기 범위를 적용한다. 이전 제출의 점수·등급·평가·피드백을 최신 결과로 옮기지 않으며 최종 제출, 읽음 표시, 학교 진도 보고를 하지 않는다.

## 요청과 권한

각 호출은 native `/users/self/profile`의 id/login_id → fresh LearningX 전체 terms/courses → 지정 과제의 course/id/embedded own submission → `GET /api/v1/courses/:course/assignments/:assignment/submissions/:verifiedNativeUserId?include[]=submission_history` 순서다. 0.3.27부터 실제 전체 학기 수강 목록에 있는 과거 강좌도 읽으며, 제출 조건·쓰기·영수증 재확인의 default 권한 검사는 유지한다. 최대30학기·100강좌를 넘거나 학기/강좌 ID가 중복되면 부분 목록으로 권한을 판정하지 않는다. 자기 제출 경로의 새 history 목적은 이 include 하나만 허용한다. 기존 최신 상세의 `submission_comments`/`rubric_assessment` 두 include는 유지하며, 두 목적을 섞거나 `read_status`, `read_state`, observed_users, 전체 학생 목록, 임의 query를 허용하지 않는다. native에는 Canvas 쿠키만 전달하며 LearningX Bearer·SSO token을 보내지 않는다.

[Canvas Submissions 공식 문서](https://developerdocs.instructure.com/services/canvas/resources/submissions)의 self submission/history include와 [공식 serializer](https://github.com/instructure/canvas-lms/blob/master/lib/api/v1/submission.rb)의 시도별 응답을 참고했다. 공식 소스는 퀴즈 body가 평가 데이터를 포함할 수 있다고 설명한다. 따라서 history는 online_text_entry의 텍스트와 online_url의 사용자가 제출한 주소만 보여준다. 이 SDK 변경의 검사는 합성 입력이며 학교 설치 버전의 실제 지원을 보장하지 않는다.

## 반환 계약

```ts
type Field =
  | { state: 'missing' | 'null' | 'not_applicable'; value: null }
  | { state: 'available'; value: string };

type History = {
  courseId: string;
  assignmentId: string;
  state: 'available' | 'missing' | 'null';
  coverage: 'school_returned';
  observedAt: string;
  currentAttempt: number | null;
  items: null | Array<{
    key: string; // /^a_[a-f0-9]{64}$/
    attempt: number | null;
    submittedAt: string | null;
    workflowState: 'unsubmitted' | 'submitted' | 'graded' | 'pending_review' | 'unknown';
    submissionType: SchoolSubmissionType | null;
    content: { text: Field; url: Field };
    attachments: SchoolAssignmentAttachment[] | null;
    isCurrent: boolean | null;
  }>;
};
```

- `missing`·`null`의 items는 null이다. 실제 학교 `submission_history: []`만 available/[]로 반환한다. 최신 제출을 이력에 복제하지 않고 전체 이력이 완전하다는 `complete` 필드는 만들지 않는다.
- 각 행의 user_id/assignment_id를 본인·과제와 대조한다. 선택적으로 제공한 course_id도 일치해야 한다. 누락된 시도 번호를 0·순서 번호로 채우지 않는다. 실제 0은 유지하지만 다운로드와 최신 동일 확인에 사용하지 않는다.
- 같은 attempt의 일치하는 중복은 제거하고 내용·시각·상태·파일 관계가 충돌하면 전체 조회를 실패시킨다. 시도 번호 내림차순으로 제공하며 번호가 없으면 뒤에 둔다.
- key는 검증한 계정·강좌·과제·시도·시각·제출 방식·안전한 내용·파일 ID 결합의 SHA256이다. native 제출/학생 ID나 발급 URL을 담지 않으며 이 값 자체가 파일 조회 권한은 아니다. 평가·workflow나 signed URL 회전으로 key를 바꾸지 않는다.
- `isCurrent=true`는 양의 attempt, 제출 시각, 방식, 적용되는 내용과 파일 ID가 latest own submission과 일치하는 경우다. 확인 자료가 없거나 같은 번호의 내용이 다르면 null이며, 알려진 번호가 다르면 false다. 퀴즈·미지원 방식의 body를 이용해 동일성을 판단하지 않는다.
- Field는 누락/null/명시적 빈 문자열을 구분한다. HTML은 기존 일반 텍스트 sanitizer로 정리하고 활성 요소를 제거한다. URL은 사용자가 제출한 HTTP(S) 주소로, 자격정보/제어문자/공백/과도한 길이와 잘못된 URL을 거부한다. 자동 외부 미리보기나 요청은 없다. 다른 제출 방식은 not_applicable다.
- 첨부의 null/[]를 보존한다. 원본·서명·preview URL, 학교 신원과 평가 필드는 DTO에 없다. 안내/목록/현재 제출 DTO 계약은 유지한다.

## 이전 시도 파일

`assignmentSubmissionHistoryAttachment(courseId, assignmentId, attemptKey, fileId, {signal?})`는 위 전체 신원·수강권한·과제·본인 이력을 다시 읽어 key를 재계산한다. 해당 행의 실제 양의 attempt와 그 행에 연결된 file ID의 발급 URL이 검증돼야 한다. 호출자가 보내는 key/file ID 또는 오래된 cache는 권한 근거가 아니다. 누락/null 이력, 사라진 시도, 다른 시도의 파일, 외부 URL 또는 미지원 query는 바이트 요청 전에 거절한다.

반환은 기존 파일 receiver와 같은 `{fileId,fileName,contentType,bytes}`다. native Canvas host, 같은 file ID의 download path, 허용 query, 최대 3 hop·20MiB 제한을 유지한다. 주소가 `/courses/:course/files/:file/download`이면 최초 발급 주소와 redirect 뒤 모두 지정 강좌가 일치해야 한다. `/files/:file/download`는 계속 지원하며 기존 latest receiver의 course 처리 방식은 바꾸지 않는다. 파일 바이트 수신 뒤에도 전체 취소/마감 시각을 확인한다. Backend는 자기 ALMS owner/generation을 시작·요청 전·최종 응답 전에 별도로 검증하고, 시도 key를 cache key와 HTTP 경로에 포함한다.

## 상한과 오류

전체 60초, 최대 30 GET, JSON 응답 2MiB·합계 8MiB, history 100행, 시도별 첨부 100개, 정규화 history DTO 1MiB를 제한한다. 초과를 잘라 부분 성공으로 반환하지 않는다. 타입/중복 충돌은 unexpected_response, 본인·과제·파일 이탈은 forbidden_target, 상한 초과는 unsupported, 취소/기한은 retryable upstream_unavailable이다. 원문·URL·cause를 오류에 넣지 않는다. 사용자 jar는 호출자별로 격리하며 저장 세션·암호화 cache·generation 관리는 Backend 책임이다.
