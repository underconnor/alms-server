# Syllabus renderer and PDF callback contract

This is a server integration contract. A rendered PDF still requires a school-backed runtime check before a service can claim syllabus support. The SDK does not launch a browser, submit report RPCs, record learning progress, or persist school sessions.

## Fresh renderer plan

`LearningxClient.prepareCourseSyllabusRender(courseId, signal?)` performs five bounded GET reads: fresh terms, owned courses, the selected course, its SIS-bound iframe, and the issued OZ launcher. The existing literal launcher parser verifies the report settings and binds UNAME/P_RANDOM to the issued query. Authentication has **not** completed at this point.

Version 0.3.18 accepts exactly the observed general `zcm_get_abeek_plan_2018_new` and engineering `zcm_get_abeek_plan_2018_new_kong` reports. The issued `ozrname` must match the report file, ODI name and parameter keys, literal authentication call, and later browser authentication request. A different supported report cannot be substituted into an existing plan. Unknown variants remain unsupported; transport hosts, paths, cookies and request bounds are unchanged.

The returned `SchoolSyllabusRenderLaunch` is an opaque, process-local handle. `inspectSchoolSyllabusRenderLaunch(handle)` is for the server renderer only and exposes `courseId`, `launcherUrl`, `launcherHtml`, `viewerId: 'OZViewer'`, and `authenticationChecked: false`. Both the handle and accessor result hide issued data from JSON and Node inspection. The accessor fields are non-enumerable. Do not send them to a browser client, logs, storage, telemetry, or another account.

The renderer must supply that exact HTML once, as the initial document at the issued launcher URL, in a new isolated browser context. It must preserve the school authentication call; a successful callback cannot be synthesized. Runtime asset/report routes, resource limits and current Backend owner/session generation remain the caller's responsibility. No generic school host or cookie scope is widened.

## Actual browser authentication check

`SchoolHttpClient.readSyllabusRenderAuthCheck(plan, requestUrl, signal?)` accepts a single actual browser GET to the exact ECC authentication path. It binds `uname`, `ozrname`, and `random` to the plan, permits only the installed jQuery JSONP callback shape and optional numeric cache-buster, and rejects duplicate or extra query keys. The plan is bound to the same HTTP client and cannot be authenticated through another account's client. A valid claim is consumed before the network request; a failure does not enable retry.

The helper uses destination-scoped SAP cookies while excluding `xn_api_token`, `sToken`, `sIdno`, and Authorization. It follows at most the already measured SAP language/client redirect with identical query values. Response cookies are not stored. The original exact success body is returned as `{body, contentType: 'text/javascript'}` after inert validation, for fulfillment of that browser request. Denial or unexpected script rejects the operation; no success body is invented.

All preparation and authentication reads share a 60-second deadline from the first catalog read, honor caller cancellation, and retain 15-second per-read and 2MiB response bounds. Expired, cloned, reused or mismatched handles are rejected. The original `prepareCourseSyllabus()` remains authentication-check-only with the same six/seven GET behavior and `documentAvailable: false` result.

The query shape comes from the school's public `authcheck_utf.js` (`callback=?`, JSONP GET) and bundled jQuery 1.8.3 (numeric callback suffix and cache-buster). This is static-source evidence, not proof that the renderer has acquired a real document.

## PDF callback normalization

`parseSchoolSyllabusPdf(output, {inspectPdf, signal?})` accepts one official memory callback string. It rejects empty/multiple/duplicate entries, unsafe filenames, noncanonical base64, output above 16MiB, unsupported PDF headers, and missing/trailing-invalid EOF. The filename is never used as a path or returned.

`inspectPdf(bytes, signal)` is required. The caller supplies a real PDF parser which rejects malformed or encrypted files and returns `{pageCount}` only after inspecting the structure. A separate byte copy prevents that parser from changing the output. Page counts must be integers in 1–1000. Parser errors become fixed `SchoolError('unexpected_response')`; cancellation/timeout becomes `upstream_unavailable`. No raw parser errors, content or causes survive.

The SDK bounds asynchronous waiting; it cannot preempt a parser that blocks the JavaScript thread. The Backend inspector must run structural parsing in an isolated worker/process with its own execution deadline and memory limits.

On success, `SchoolSyllabusPdf` provides `contentType`, `byteLength`, `pageCount`, and server-only `bytes`. The bytes are non-enumerable and excluded from JSON/Node inspection. These checks validate the export format; the caller must also verify successful school auth, current owner/generation and course binding before caching or serving it. No attendance/progress callback belongs to a syllabus read.

## Validation and remaining gate

Synthetic tests cover real-shaped PDF bytes, required structural inspection, corruption, duplicates, limits, cancellation, parser failures, fresh ownership, private handles, exact auth query binding, per-client isolation, response preservation, redirects and no retry. They do not prove school PDF acquisition. The next integration gate is the normal official viewer's actual memory output, its bounded network behavior, a real PDF parser, and comparison with the owned school's syllabus.

Primary sources:

- [School authentication script](https://office.ssu.ac.kr/oz70/authcheck_utf.js)
- [School jQuery 1.8.3](https://office.ssu.ac.kr/oz70/ozhviewer/jquery-1.8.3.min.js)
- [FORCS memory export callback](https://global.forcs.com/file/manual/global/documentation-rv_dev/rv_event_ozexportmemorystreamcallback.htm)
- [FORCS ScriptEx](https://global.forcs.com/file/manual/global/documentation-rv_dev/rv_method_scriptex.htm)
