# Readystream 단일 영상 · 0.3.39

학교가 실제로 반환한 정확한 `attendance_item/commons/readystream`을 조회한다. 공개 상세·학습 상태의 `resourceType`과 private launch/callback의 `contentType`은 `readystream`으로 보존한다. 모듈과 상세의 강좌·활동 ID, 원본 유형, 모듈에 제공된 content ID를 대조한다. 모듈·항목 ID 중복과 다른 Commons 유형까지 포함한 동일 attendance ID의 복수 후보는 거절한다. 제목으로 관계를 만들지 않는다.

## 조회와 권한

`parseModules`는 정확한 Readystream 관계에 `activityDetailAvailable:true`와 기존 `todoReferenceAvailable:true`/`attendanceItemId`를 제공한다. 상세는 안내 텍스트·학교 flags·초 단위 duration/progress/last position을 읽는다. 학습 상태는 원래 completed와 출석 상태를 보존하고 `recognized:null`을 유지한다. 이 메타정보나 marker는 재생·보고 권한이 아니다.

통합 담당자는 2026-10-20 기존 .38에서 본인 신원·수강 강좌·모듈·상세를 8 GET으로 확인했다. 선택 영상의 detail duration은 1158.14초로 익명 manifest/story 1158.14초와 일치했고, native duration은 약 1158.118초였다. 학교 공개 LearningX 소스도 Readystream을 영상으로 분류하고 초 단위 표시와 progress/duration 비율을 사용했다. 이는 단위·조회 계약의 근거이며 SDK .39의 실제 보고 ACK·학습 완료·출석 인정 성공을 뜻하지 않는다.

## 검증한 단일 UPF 형식

`resolveSchoolVideoMedia`는 기존대로 anonymous viewer와 발급 manifest만 2 GET으로 읽는다. Cookie/Bearer/Referer를 보내지 않고 script를 실행하지 않는다. Readystream은 다음 조건을 모두 만족하는 UPF만 받는다.

- version 1.0의 한 content, 한 story, `story_type:video1`, 한 main media와 정확한 default/media ID
- fresh detail과 같은 content ID·content/story duration
- 정확한 Commons `contents31/ssu1000001/:contentId/contents/web_files` root와 같은 service web 값
- 동일한 all/mobile progressive template: `https://ssu-toast.commonscdn.com/contents31/ssu1000001/:contentId/contents/media_files/[MEDIA_FILE]`
- 같은 content의 정확한 `contents31_pseudo` fallback template. 이 주소는 요청하지 않는다.
- 한 MP4 basename. 관찰한 ASCII 괄호 `()`는 이 Readystream 분기에서만 허용한다. Unicode·공백·percent·슬래시·query·fragment·중첩 경로는 거절한다.

다중 story/media·문서/슬라이드·HLS·알 수 없는 재생 구조·DTD/entity·틀린 host/content/tenant/template/duration은 대체 경로 없이 거절한다. 기존 movie의 contents15 UPF·contents29/31 video1 및 basename 허용 범위는 유지한다. SDK의 generic `schoolUrl` host 목록은 바꾸지 않는다. CDN byte 취득과 검증한 Referer profile은 Backend 스트리머의 별도 계약이다.

## launch별 private 검증과 보고

완전한 단일 영상 검증과 최종 취소 검사를 통과한 **해당 opaque launch 객체**에만 package-internal WeakSet 검증을 남긴다. public entrypoint에 mint 함수나 검증 상태 accessor를 추가하지 않는다. callback binding, native/manual report controller, report request, 명시적 start controller 생성은 Readystream의 이 검증을 확인한다. 다른 launch·같은 ID의 새 객체·실패/취소한 해석에는 승계하지 않는다. movie의 기존 생성 순서는 유지한다.

Backend는 Readystream의 최초 callback binding 전에 같은 launch로 media를 해석해야 한다. 반환 media를 이어 쓰면 metadata GET을 중복할 필요가 없다. 새 학교 읽기는 기존 binding과 exact type/content/course/module/item/duration/issued target을 비교한다. 새 launch로 binding을 만드는 별도 명시적 start에는 그 launch 자체의 새 media 검증이 필요하다. SDK는 세션·학교 generation·실행 nonce·소유권·공용 lease를 대체하지 않는다.

학교 공개 `uni-player.min.js` SHA-256 `33a299812f27eb18c866e33f124e4c7ad1f198eaf822f80e679fce71335acb68`에서 페이지 초기값은 0/0/빈 문자열이고 setter 호출은 docPlayer 분기에 있었다. `uniplayer_cscript.js` SHA-256 `7e6153460179083c25bc9263b76a69d1189b669e870bb5393d81cb4ee5a80a15`는 이 getters를 보고하고 정기 간격은 300,000ms다. 따라서 검증한 단일 video1 UPF만 기존 `page=0,totalpage=0,cumulativePage=''` 보고 계약을 재사용한다. 원본 소스는 이 저장소에 복사하지 않는다.

발급 TargetUrl의 `content_type=readystream`을 정확히 대조한다. 발급 `endat === progressSeconds`, 공개/열림/omitProgress·duration, 1배속·seek/가시성, 관측 freshness·단조 시계·서버/클라이언트 진도 상한, 단일 전송·재전송 금지와 strict 일반 ACK 조건은 그대로다. 보고 뒤 fresh 학교 값의 resource type도 기존 launch와 같아야 한다. 별도 start의 사람 확인·일회권과 ACK 계약도 바꾸지 않는다.

Backend는 단일 UPF 검증 성공 뒤에만 manual capability를 표시한다. 서버 자동수강·임의 Readystream 형식·슬라이드 재생을 지원으로 바꾸지 않는다. SDK의 source/media `callbackVerified:false`와 binding `reportingVerified:false`도 유지한다. 합성 회귀·단위/manifest 조사·미디어 HEAD/range·실제 보고·영상 종료·학교 진도와 개별 출석·차시 인정·새 로그인·배포는 각각 별도 검증 단계다.
