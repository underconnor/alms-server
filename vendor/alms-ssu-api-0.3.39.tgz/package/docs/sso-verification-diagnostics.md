# u-SAINT 신원 확인 실패 진단

`SchoolSsoVerificationError`는 기존 `SchoolError`의 subclass다. `code`, `message`의 고정 코드, `retryable`을 유지하므로 기존 `instanceof SchoolError`와 코드별 처리에 호환된다. 생성자는 `(code, verificationStage, retryable = false, identityShape?, portalDiagnostics?)` 순서다. 마지막 인자는 0.3.13에서 추가한 선택 값으로, 이전 호출은 그대로 동작한다. 패키지 entrypoint에서 class와 진단 enum·interface 타입을 export한다.

| verificationStage | 실패한 경계 |
| --- | --- |
| `input` | callback 입력 형식 또는 기존 쿠키용 URI encoding 검증 |
| `sso_entry` | 기존 Saint 쿠키 준비와 `/webSSO/sso.jsp` 요청 |
| `portal_page` | `/webSSUMain/main_student.jsp` 요청 |
| `identity_parse` | 성공한 페이지 응답의 기존 신원 DOM 파싱·callback 학번 대조 |

HTTP 401/403, 서버 응답 오류, HTTP 200의 실제 로그인 폼 거부는 실패한 요청 단계에 남는다. 포털 읽기가 정상으로 끝나기 전에 DOM 누락으로 분류하지 않는다. `parseUsaintIdentity`를 직접 호출했을 때도 기존 오류 대신 호환되는 subclass를 반환한다.

`identityShape`는 `identity_parse`의 해당 오류에만 존재한다. `authentication_required`에는 `missing_student`, `missing_name`, `missing_both`, `identity_mismatch`에는 `id_mismatch`를 사용한다. 이름이 없으면서 다른 학번이 보이는 경우는 기존과 같이 먼저 `authentication_required`로 처리한다. DOM·학번·이름·본문·발급 URL·토큰·쿠키·원래 오류 message/cause를 진단에 넣지 않는다.

## 0.3.13: 실패한 포털 화면의 형태

유효한 `identity_parse`/`identityShape` 조합에만 `portalShape`와 `portalMarkup`을 추가한다. `portalShape`는 다음 고정 enum 중 하나다.

| portalShape | 정적으로 관찰한 형태 |
| --- | --- |
| `identity_markup` | 기존 신원 컨테이너 또는 학번 행이 있음 |
| `password_form` | password input을 가진 form이 있음 |
| `literal_navigation` | 제한된 인라인 JavaScript 문법에서 location 대입 또는 assign/replace에 문자열 리터럴을 사용함 |
| `frame_shell` | frame 또는 iframe 요소가 있음 |
| `mixed` | 위 증거가 둘 이상 존재함 |
| `unknown` | 검사한 문법에서 위 증거가 없음 |
| `inspection_limited` | 크기·개수 상한 또는 진단기가 해석하지 않는 script 문법을 만남 |

`portalMarkup`은 `identityContainerPresent`, `studentRowPresent`, `studentValuePresent`, `nameValuePresent`, `passwordFormPresent`의 boolean 다섯 개만 담고 변경할 수 없도록 동결한다. 생성자는 허용한 속성만 복사한다. 실제 학번·이름·선택자 값·이동 주소·query·script·내용 해시를 넣지 않는다. Backend도 `instanceof`, 고정 enum, boolean 형식을 다시 확인해 필요한 속성만 전달해야 한다.

HTML 길이 512KiB, 실행 가능한 타입의 인라인 script 64개, 해당 script 합계 64KiB, 개별 토큰 8,192개를 상한으로 사용한다. 주석과 문자열 내부의 가짜 코드는 이동 증거로 쓰지 않는다. 외부 script·JSON script는 읽거나 실행하지 않는다. 정규식 리터럴과 template literal은 해석하지 않고 `inspection_limited`를 반환한다. 이 제한은 실패 진단에만 적용하며 기존 신원 파서나 HTTP 크기 제한을 변경하지 않는다.

`literal_navigation`은 코드 형태가 있다는 뜻이며 실제 브라우저 이동, 로그인 거부, 해당 함수 실행을 뜻하지 않는다. `mixed`와 `unknown`만으로 실패 원인을 결정하지 않는다. HTTP 계층이 이미 거부한 실제 로그인 폼은 기존 `portal_page` 실패를 유지하며, 이 진단을 위해 원문을 오류에 추가하지 않는다. 성공한 신원에서는 추가 형태 검사를 수행하지 않는다.

2026-10-02 익명 `main_student.jsp` GET 1회에서 HTTP 200과 신원 컨테이너·password input·frame 부재, location 문자열 리터럴 대입 존재를 확인했다. 쿠키·인증 자료·redirect 추적·학교 쓰기를 사용하지 않았으며 원문은 보존하지 않았다. 이는 익명 화면도 이런 형태일 수 있다는 비교 근거다. 이전 인증 실패의 화면이 같았거나 원인이 밝혀졌다는 증거가 아니며, 다음 정상 callback에서 나온 진단을 별도로 확인해야 한다.

기존의 알려진 `SchoolError`만 새 subclass로 감싼다. 알 수 없는 내부 예외는 원래 객체를 그대로 전파하며 임의 속성에서 단계나 오류 코드를 추정하지 않는다. Backend가 운영 로그에 기록할 때도 class와 고정 enum을 확인해야 하며 원본 오류 전체를 직렬화하지 않는다.

성공 신원, 학교 요청 순서, query의 토큰 값과 기존 쿠키 encoding, host 범위, 요청 횟수, 재시도 정책은 바꾸지 않는다. 추가 학교 요청·자동 로그인 재시도·인증 우회는 없다. 이번 구현과 합성 검사는 실제 새 인증을 실행하지 않았고, 현재 관찰된 `school_identity/authentication_required`의 세부 원인을 소급해서 확정하지 않는다. 다음 정상 인증에서 나온 진단과 신원 결과를 별도로 확인해야 한다.


## v0.3.33: failed identity HTML navigation syntax

`SchoolSsoVerificationError.portalNavigation` adds four optional fixed enums to the existing failed identity diagnostic. This is diagnostic-only: the error code, identity decision, callback binding, token encoding, two Saint requests, transport scope and absence of automatic retry are unchanged.

- `scriptPlacement`: `none`, `outer_statement`, `nested_or_expression`, `mixed`, `inspection_limited`. An outer statement means only a literal location expression at an unbracketed token boundary. A nested expression may be in an uncalled function, a conditional or another expression. Neither value proves execution, a redirect, or authentication.
- `scriptTarget`, `formTarget`, `metaRefreshTarget`: `none`, `saint_sso_entry`, `saint_identity_page`, `other`, `mixed`, `inspection_limited`. Only the exact existing paths `/webSSO/sso.jsp` and `/webSSUMain/main_student.jsp`, either root-relative without a document base or prefixed by the exact Saint HTTPS origin, get named roles. Query and fragment text are discarded. Escapes, encoded/normalized/relative paths, other origins and ambiguous values stay `other`.
- Script literals are not decoded, evaluated or followed. Inline handlers, external scripts and inert JSON remain outside script inspection. Form actions and literal refresh metadata only classify static attributes; no submission or navigation occurs.
- Existing HTML 512 KiB, inline script 64 KiB/64-script and 8,192-token limits remain. Form/meta inspection is capped at 64 elements per kind; a destination longer than 4,096 characters is `other`. Unsupported syntax or exceeded limits produces fixed limitation evidence.
- The error copies exactly four enum fields into a frozen object. No original destination, URL, query, token, identity, script, HTML, content hash or arbitrary field is retained.

The two actual v42 failures had LMS exchange ready and Saint entry/identity HTTP 200 with missing identity markup and `literal_navigation`. Those earlier logs lack navigation placement or target evidence, so this patch cannot establish their cause. Synthetic checks establish diagnostic contracts only; a new callback is required for actual failure evidence.
