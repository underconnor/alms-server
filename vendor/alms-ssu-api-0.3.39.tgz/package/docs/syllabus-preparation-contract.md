# 강의계획서 준비 흐름 · 미출시

## 0.3.18 · 학교 발급 공학형 보고서

학교 발급 일반형 `zcm_get_abeek_plan_2018_new`와 공학형 `zcm_get_abeek_plan_2018_new_kong` 두 보고서명만 허용한다. 운영 조사에서 공학형 launcher와 보고서·ODI·servlet의 일치가 확인됐고, 기존 일반형 한 개만 허용하던 파서가 해당 문서를 `unsupported`로 거절했다. 실제 발급값·HTML은 fixture에 포함하지 않았다.

launcher의 `ozrname`, `connection.reportname`, `odi.odinames`, `odi.<보고서명>.pcount/args`, `requestSend`와 브라우저 authcheck의 보고서명이 모두 같아야 한다. 다른 이름이나 접두사·접미사 변형, 일반형/공학형 혼합은 계속 거절한다. host·경로·쿠키 범위, 원문 비공개, 요청·바이트 제한과 인증 실패 처리는 유지한다. 아래 문서는 최초 준비 구현의 경계이며, 이 버전의 합성 검사와 실제 PDF 취득·배포 검증은 구분한다.

`LearningxClient.prepareCourseSyllabus(courseId)`는 현재 학생의 소유 강좌를 새로 확인하고 학교 OZ 인증 확인까지 수행한다. 성공 결과는 `{status:'authentication_checked', documentAvailable:false}`다. 보고서·PDF·첨부 취득이나 native Canvas 인증 성공을 뜻하지 않는다. Backend/Front provider는 이 변경에 포함하지 않으며 실제 학교 요청·새 버전 발행·배포는 하지 않았다.

## 확인 범위와 근거

기존 읽기 조사에서 LearningX 강좌 JSON → SIS에 결합된 iframe → 학교 발급 OZ launcher를 확인했다. ECC 인증 확인은 기존 SAP 호환 UA와 학교 발급 언어/클라이언트 redirect를 사용하면 200·`jsonpCallback()`을 반환했다. 학교 브라우저의 PDF 저장도 관찰했지만 Backend 문서 취득은 아직 구현되지 않았다. 이 구현 자체의 학교 동작은 합성 검사와 별도로 검증해야 한다.

학교 1차 출처는 [LearningX Dashboard](https://canvas.ssu.ac.kr/learningx/js/Dashboard/dashboard-view.app.js?version=4.82.9), [OZ 인증 확인 JS](https://office.ssu.ac.kr/oz70/authcheck_utf.js), [OZ Viewer](https://office.ssu.ac.kr/oz70/ozhviewer/OZJSViewer.js)다. 원본 학교 응답·발급 값·강의자료를 라이브러리나 fixture에 복사하지 않았다.

## 고정 읽기 순서

1. `GET /learningx/api/v1/users/:userLogin/terms?include_invited_course_contained=true`
2. `GET /learningx/api/v1/learn_activities/courses?term_ids[]=...` — 최대 30개 학기, 요청 강좌가 정확히 한 번 있어야 한다.
3. `GET /learningx/api/v1/courses/:courseId` — 응답 `id`와 요청을 대조한다.
4. 같은 응답 `sis_source_id`와 일치하는 발급 iframe `/learningx/courses/:sisSourceId/syllabus`
5. 정확한 `https://office.ssu.ac.kr/oz70/ozView.jsp` — 학교의 zero-delay meta refresh URL만 사용한다.
6. 정확한 `https://ecc.ssu.ac.kr/sap/bc/bsp/sap/z_oz_authcheck/check.htm`
7. 학교가 302로 발급한 경우에만 `/sap(bD1lbiZjPTEwMA==)/bc/bsp/sap/z_oz_authcheck/check.htm`로 1회 이동한다.

모두 GET이고 전체는 60초, 각 읽기는 최대 15초, 각 응답은 최대 2MiB다. 사용자 설정의 더 작은 timeout/response 상한은 유지한다. 응답 스트림·fetch가 AbortSignal을 무시해도 대기를 끝낸다. 보고서 `/oz70/server` 호출·출력·학교 학습 보고·자동 재시도는 없다.

현재 학기 목록은 fresh school 응답의 최대 30개를 모두 사용한다. 기간을 임의로 선택하거나 강좌 이름으로 소유권을 추정하지 않는다. 현재 Backend 사용자·학교 세션 generation·실제 학생 신원은 이 메서드를 호출하는 Backend가 검증하고 반환 전 다시 확인해야 한다. `SchoolHttpClient.prepareCourseSyllabus(courseId,userLogin)`는 인증된 LearningxClient가 사용하는 transport 진입점이며 인증을 새로 성립시키는 메서드가 아니다.

## 파서와 인증 경계

- `parseCourseSyllabusEntry`는 fresh owned-course ID 목록·응답 강좌·SIS iframe을 결합한다. 누락, 명시적 빈 문자열, 일반 HTML은 각각 `missing`, `empty`, `unsupported_html`로 구분한다. 잘못된 타입은 오류다. 준비 흐름에서 이 세 상태를 문서 성공으로 반환하지 않는다.
- `parseSyllabusLauncher`는 한 개의 정확한 zero-delay meta refresh와 관찰한 report/query 구조만 받는다. 외부 목적지·중복/추가 query·동적 script는 실행하지 않는다.
- `parseSyllabusAuthCheck`는 관찰한 `SetOZParamters_OZViewer`, `call`, `requestSend`의 리터럴 문법만 해석한다. 설정의 report/servlet/parameter 개수·모든 보고서 인자와 발급 query를 대조한다. `UNAME` 및 `P_RANDOM`은 각각 `requestSend`의 발급 사용자값·일회성 값과 같아야 한다. 발급 사용자값은 숫자 학생 ID 형태가 아니므로 학번과 임의로 동일시하지 않는다.
- iframe/launcher/authcheck 중간 handle에는 고정 `kind`만 있다. 발급 URL·SIS·사용자값·일회성 값은 private WeakMap에 저장한다. JSON·inspect·오류에 노출하지 않으며 handle을 복제하거나 임의로 만들면 거절한다. 내부 URL accessor는 패키지 entrypoint에서 export하지 않는다.
- LearningX Bearer는 Canvas `/learningx/`에만 사용한다. OZ launcher는 jar 읽기/저장 없이 익명으로 읽는다. ECC는 목적지의 jar domain/path 규칙으로 쿠키를 다시 고르므로 정상 parent-domain SAP 쿠키를 사용할 수 있다. `xn_api_token`, `sToken`, `sIdno` 및 Authorization은 ECC에 보내지 않는다. 원래 generic `get()`, host 집합과 ECC 시간표 경계는 바뀌지 않는다.
- 준비 transport는 Set-Cookie를 저장하지 않는다. 기존 jar의 목적지 쿠키를 읽는 데만 사용하며 DB 저장도 하지 않는다. 이후 실제 응답에서 새 쿠키 전달이 필요하다고 확인되면 별도 계약으로 검토한다.
- authcheck redirect는 원문 경로부터 정확히 비교하며 dot segment/인코딩 변형을 정규화로 허용하지 않는다. query의 키 개수·중복·원래 값을 재검증하고 다른 redirect는 거절한다.
- `parseSyllabusAuthResponse`는 정확한 `jsonpCallback()`만 성공으로, `jsonpFailure()`는 인증 실패로 처리한다. HTML·추가 JS·누락·잘못된 callback은 오류다. 응답 script를 실행하지 않는다.

## 다음 게이트

합성 검사는 학교 실제 동작 증거가 아니다. 현재 사용자와 generation을 확인한 읽기 전용 QA에서 같은 경로를 검증한 뒤에도 결과는 인증 확인까지다. 실제 PDF 취득은 학교 Save → PDF의 추가 HTTP 요청 또는 메모리/Blob 출력 경계를 확인한 후 별도로 구현한다. 원본 발급 URL을 Front에 주거나 iframe 링크만으로 내부 열람을 완료 처리하지 않는다. 새 본문/PDF DTO, 캐시, 학습 진도 callback은 이 변경에 포함하지 않는다.
