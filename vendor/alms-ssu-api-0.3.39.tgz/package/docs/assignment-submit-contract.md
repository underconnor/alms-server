# 과제 제출·첨부 계약

## 구현과 실제 근거

0.3.21은 제출 조건 조회, 파일 준비/최종 전송, 본인 제출 재확인, 과제에 연결된 첨부 읽기를 추가한다. 공개 저장소에는 합성 입력만 사용한다. 통합 담당자가 현재 학교의 본인 신원·수강 강좌·과제·본인 제출·native HTML을 읽어 파일 제출 폼과 CSRF 쿠키, 개인 과제 조건을 확인했다. 학교 공개 스크립트에서도 파일 ID를 발급받은 뒤 native 제출 폼에 연결하는 순서와 동의 checkbox의 밀리초 시각을 확인했다. 실제 학교의 업로드/최종 제출 쓰기와 첨부 바이트는 이 PR에서 실행하지 않았다.

학교에서 관찰한 native `POST /courses/:course/assignments/:assignment/submissions`에 학교 폼이 발급한 제출 방식만 보낸다. 업로드 초기화는 [Canvas Submissions](https://developerdocs.instructure.com/services/canvas/resources/submissions), 파일 전송/완료 순서는 [Canvas File Uploads](https://developerdocs.instructure.com/services/canvas/basics/file.file_uploads)를 따른다. 표준 경로가 있다는 사실을 현재 학교에서 성공한 것으로 설명하지 않는다. [공식 controller](https://github.com/instructure/canvas-lms/blob/master/app/controllers/submissions_controller.rb)는 필드 의미를 확인하는 참고이며 소스 구현을 복사하지 않았다.

## 서버 API

- `assignmentSubmissionOptions(course, assignment, {signal})`: native self ID/login을 bootstrap과 비교하고 학교 default 학기(표시가 없으면 서버 순서 첫 학기)의 수강 강좌를 확인한다. 이 초기 선택은 활성 수강의 증거가 아니며 기존 학교 조건을 계속 검증한다. 상세·본인 제출·발급 폼을 읽어 `supported`, `modes`, `blockedReason`, `expectedAttempt`, `allowedExtensions`, `groupSubmission`, `pledge:{required,text,digest}`를 반환한다. 학교 신원·폼 토큰·URL은 반환하지 않는다.
- `submitAssignment(course, assignment, input, hooks)`: input은 제출 방식, `expectedAttempt:number|null`, `pledgeAcceptedAt:string|null`, `pledgeDigest:string|null`와 파일/텍스트/URL 중 해당 내용만 받는다. 학교 사용자 ID·file ID·URL을 입력으로 받지 않는다. 파일은 `{fileName,contentType,bytes:Uint8Array}`다. 호출 시 내용을 복사해 이후 호출자의 변경을 차단한다.
- `reconcileAssignmentSubmission(course, assignment, receipt, {signal})`: 새 본인 신원과 기존 default 학기 수강권한·상세·본인 제출 GET만 수행한다. 최종 POST나 업로드는 실행하지 않는다.
- `assignmentAttachment(course, assignment, file, {signal})`: 0.3.27부터 새 본인 신원·전체 학기 수강권한과 과제를 검증한다. 새 학교 응답의 본인 첨부 또는 해당 과제 안내의 발급 링크에 들어 있는 파일만 `{fileId,fileName,contentType,bytes}`로 돌려준다. 읽기의 성공은 제출 권한을 뜻하지 않는다. 외부 저장소·다른 파일/사용자·임의 URL은 거절한다. 응답을 공개 웹 파일 경로에 저장할 권한을 뜻하지 않는다.

`beforeUpload()`는 첫 학교 파일 쓰기 직전에 한 번 실행한다. `beforeWrite(receipt)`는 파일 준비 후 본인/조건/동의 문구를 재검증하고 최종 제출 직전에 한 번 실행한다. Backend는 이 hook에서 영속 상태와 실행권·현재 세션/generation을 확인해야 한다. hook 실패·취소면 다음 학교 쓰기는 시작하지 않는다. 이미 전송한 요청은 취소만으로 회수되었다고 판단하지 않는다.

## 조건과 범위

개인 과제임이 명시되고, 공개/잠금/제출 횟수와 발급 form을 확인한 경우만 지원한다. group_category_id 누락은 개인 과제로 가정하지 않는다. 그룹 과제, 미지원/누락된 방식·횟수, excused와 알 수 없는 상태는 차단한다. 명확한 unsubmitted의 null attempt는 신규 제출로 허용하되 숫자 0으로 바꾸지 않는다. 이전 시도가 있으면 요청 expectedAttempt와 학교 값이 같아야 한다. 기한 dueAt만 지났다는 이유로 거절하지 않으며 unlock/lock/학교 lockedForUser를 검사한다. 최종 권한은 학교가 다시 검증한다.

학교 동의 checkbox가 있으면 문구를 읽어 digest를 만든다. Front가 실제 표시한 digest와 Backend가 명시적 동의 요청을 받은 시각을 전달해야 한다. 임의 true/현재 시각을 자동으로 만들지 않는다. digest 불일치·30분 이상 지난 동의·5초 이상 미래 시각은 차단한다. 학교 쓰기 직전 다시 발급된 문구가 달라도 중단한다.

파일당 20MiB, 최대 5개, 합계 40MiB이며 비어 있는 파일·중복 이름·경로/제어문자가 포함된 이름과 학교 제한 확장자를 거절한다. Backend는 별도로 임시 파일 경로, 암호화, 사용자/전체 quota, TTL, 동시성, 스트리밍 수신 제한을 보장해야 한다. SDK의 파일 bytes 계약 자체는 디스크·암호화 저장을 구현하지 않는다. 텍스트는 128KiB까지이며 실행 가능한 HTML로 받지 않고 escape한 문단/줄바꿈으로 보낸다. URL은 HTTP(S) 문자열로 제출하고 SDK가 그 URL에 접속하지 않는다.

업로드는 verified self의 `/api/v1/courses/:course/assignments/:assignment/submissions/:self/files` 초기화 후 발급된 같은 Canvas의 `/files`, `/files/pending` 또는 `/files_api` receiver만 허용한다. 기존 두 경로는 쿼리가 없어야 하며, 0.3.34의 `/files_api`에서만 아래 두 매개변수를 추가로 지원한다. 발급 필드는 제한된 크기로 그대로 전달하고 file part를 마지막에 둔다. 새 host나 자동 제출 `submit_assignment=1` 경로는 지원하지 않는다. 완료 redirect는 같은 Canvas의 `/api/v1/files/:id/create_success` GET 한 번만 허용하며, `uuid` 한 개와 receiver에 발급된 정확한 두 값 외의 쿼리는 거절한다. 이 범위는 합성으로 검사했으며 학교의 실제 업로드 성공과 구분한다.

native 요청에는 해당 jar의 native 쿠키와 `_csrf_token`에서 얻은 `X-CSRF-Token`만 쓴다. LearningX Bearer와 xn_api_token/sToken/sIdno는 전달하지 않는다. redirect에 POST/파일/쿠키를 자동 재전송하지 않는다. 모든 fetch와 응답 본문, cookie 작업, hook은 취소/기한에 묶이며 AbortSignal을 무시하는 의존성을 기다리는 시간도 제한한다. 조건/재확인은 전체60초, 제출은 전체240초이며 각 HTTP 요청은 client timeout과 GET30초/POST120초 중 짧은 값이다. JSON/HTML 2MiB, 파일 읽기20MiB 상한을 적용한다.

## 결과와 중복 방지

`SchoolAssignmentWriteError`는 고정된 code, stage, outcome과 아래 0.3.36의 실행 경계만 담고 retryable=false다. 전송 전 실패는 not_sent, 학교가 명시적으로 거절한 400/401/403/422는 rejected, 전송 뒤 상태를 알 수 없으면 unknown이다. 응답 원문·파일명·토큰·URL·cause는 오류에 넣지 않는다. read 오류는 기존 SchoolError 규칙을 따른다.

결과는 `confirmed` 또는 `needs_confirmation`이다. 성공은 fresh 자기 제출이 submitted/graded이며 본인/과제·제출 방식·새 attempt·제출 시각·텍스트/URL digest 또는 파일 ID에 맞을 때만 반환한다. 학교에서의 의미가 아직 확인되지 않은 pending_review는 내용이 일치해도 needs_confirmation으로 둔다. 업로드 파일이 제출 과정에서 복제되면 최종 POST의 같은 본인/과제/attempt와 첨부 이름·크기를 확인하고 응답 file ID를 fresh GET과 대조한다. 단순 200, 기존 submitted, 새로운 시각만으로 성공을 만들지 않는다. 응답 유실로 복제 file ID를 알 수 없거나 내용 결합이 부족하면 needs_confirmation이다.

`SchoolAssignmentSubmissionReceipt`에는 본인/과제 ID, 이전 attempt, 본문 digest, 업로드/확인된 file ID가 들어 있다. Backend 전용 비밀 상태이며 owner/generation에 묶어 암호화 저장한다. 브라우저에서 받은 receipt나 file ID를 SDK로 전달하지 않는다. SDK가 durable idempotency를 제공하는 것은 아니다. Backend가 같은 과제의 미확정 시도·다중 인스턴스·다중 탭을 잠그고, 전송 전에 receipt를 저장하며, 재시작 후에는 읽기 재확인만 해야 한다.

## 0.3.34 · 공식 로컬 수신 경로와 발급 쿼리

공식 Instructure `canvas-lms`의 고정 commit `1c9f0bb8013ed69c4f2efe11fd483025469b7e6c`를 읽어 다음 계약을 확인했다. upstream 구현을 복사하지 않고 이 계약을 검사하는 합성 응답과 검증 코드를 작성했다. 현재 학교 서버의 버전이나 과거 응답이 이 소스와 같다고 가정하지 않는다.

- [로컬 업로드 route](https://github.com/instructure/canvas-lms/blob/1c9f0bb8013ed69c4f2efe11fd483025469b7e6c/config/routes.rb#L3083-L3085)는 `/files_api`다. [LocalStorage](https://github.com/instructure/canvas-lms/blob/1c9f0bb8013ed69c4f2efe11fd483025469b7e6c/app/models/attachments/local_storage.rb#L41-L46)는 발급된 local URL을 upload URL로 사용한다. ALMS는 기존 `https://canvas.ssu.ac.kr`만 허용하고 외부 storage를 추가하지 않는다.
- [발급 코드](https://github.com/instructure/canvas-lms/blob/1c9f0bb8013ed69c4f2efe11fd483025469b7e6c/lib/api/v1/attachment.rb#L435-L454)는 receiver와 완료 URL에 중복 이름 처리와 quota 값을 붙인다. ALMS가 요청하는 `on_duplicate=rename`만 지원한다. `overwrite`나 그 외 값은 받지 않는다.
- [과제 초기화](https://github.com/instructure/canvas-lms/blob/1c9f0bb8013ed69c4f2efe11fd483025469b7e6c/app/controllers/submissions_api_controller.rb#L710-L718)는 quota 검사를 끈다. 이때 [quota key](https://github.com/instructure/canvas-lms/blob/1c9f0bb8013ed69c4f2efe11fd483025469b7e6c/app/models/attachment.rb#L764-L770)는 [HMAC hex](https://github.com/instructure/canvas-lms/blob/1c9f0bb8013ed69c4f2efe11fd483025469b7e6c/gems/canvas_security/lib/canvas_security.rb#L181-L185)의 처음 10자리이므로 `quota_exemption=[0-9a-f]{10}`만 받는다. 키를 만들거나 추정하지 않으며 학교가 발급한 값만 그대로 전달한다.
- [receiver의 완료 redirect](https://github.com/instructure/canvas-lms/blob/1c9f0bb8013ed69c4f2efe11fd483025469b7e6c/app/controllers/files_controller.rb#L1051-L1074)는 파일 ID·uuid와 같은 두 값을 전달한다. 완료 URL은 기존 정확한 파일 경로와 `uuid` 한 개를 요구하고, 두 매개변수의 유무·값은 receiver URL과 같아야 한다. 추가·누락·변경·중복은 GET 전에 차단한다.

두 새 매개변수는 각각 0개 또는 1개다. 원본 쿼리의 이름·값을 그대로 검사하며 percent-encoded 별칭, 빈 값, 추가 `=`·빈 항목, `submit_assignment`, `include`, 임의 URL은 지원하지 않는다. URL을 재작성하지 않고 signed form 필드와 file 마지막 순서를 유지한다. 완료 GET이나 receiver 응답 유실은 `unknown`이며 자동 재전송, 최종 제출, receipt 합성으로 복구하지 않는다.

수정 전 SDK 0.3.33으로 정상 `/files_api` 및 발급 query 흐름 두 개가 `upload/unknown/unsupported`로 실패하고, 수정 뒤 같은 합성 검사가 통과했다. 과거 실제 작업의 receipt가 없다는 사실만으로 학교 파일이 전송됐는지 판단할 수 없다. `beforeUpload` 다음 초기화·receiver·완료 GET·다중 파일·최종 조건 재확인 단계에서 멈추면 최종 receipt 저장에 이르지 않을 수 있다. 실제 사용자 파일 제출과 새 학교 응답의 대조는 별도 QA다.

## 남은 학교 QA

실제 학생이 고른 과제·최종 파일/내용으로 업로드/제출을 한 번 실행하고 같은 시도의 학교 결과를 대조해야 한다. 현재 후보는 실제 쓰기 성공을 주장하지 않는다. 별도 대상에서 텍스트·URL 폼, 재제출, 파일 복제, 그룹 제출, 학교의 외부 storage, 다른 계정 격리와 학교 오류 의미를 확인하기 전에는 그 범위를 완료로 기록하지 않는다.

## 0.3.35 · 첨부 원본 파일명

`assignmentAttachment`와 `assignmentSubmissionHistoryAttachment`는 정확한 과제·파일·본인/시도 연결을 검증하고 파일 바이트를 받은 뒤 응답의 원본 파일명을 기존 `fileName:string|null`에 반환한다. 안내 링크의 일반 문구를 실제 파일명으로 저장하는 문제를 줄인다. 헤더가 없거나 유효한 이름을 얻지 못하면 기존 안내 링크 문구·본인 첨부 메타정보를 그대로 사용한다. 파일명은 권한 근거가 아니며 이 변경으로 새로운 파일이나 URL을 읽지 않는다.

다운로드의 `attachment`/`inline` 헤더에서 UTF-8 `filename*`를 우선하고, 일반 `filename`을 대안으로 사용한다. 전체 8KiB·매개변수 16개로 제한하며 중복 파일명 필드·불완전한 문법·잘못된 UTF-8과 지원하지 않는 charset은 원본 이름으로 사용하지 않는다. 해석 가능한 일반 `filename`이 있으면 그 값으로 돌아간다. 원문 헤더·signed URL·인증값은 DTO나 오류에 넣지 않는다.

결과 이름의 경로·제어문자 등은 기존 Backend 다운로드 경계와 같은 문자 집합으로 대체하며 방향 제어문자는 제거한다. 길이는 기존 240자 경계를 유지하고 자를 때 잘못된 Unicode 문자를 만들지 않는다. Backend·Front도 기존 안전한 저장 이름 처리를 유지해야 한다. Front의 Blob 다운로드는 파일 응답의 이름을 캐시에 함께 보관하고 `download`에 적용해야 하므로 SDK 수정만으로 브라우저 저장 이름이 바뀌었다고 주장하지 않는다.

학교 요청 수·대상 호스트·redirect·크기/시간 제한·쿠키 범위·업로드와 최종 제출 요청은 유지한다. 합성 안내 링크/헤더와 정확한 과거 시도 다운로드를 검사했으며 실제 학교 응답이나 OS 저장 완료 검증과 구분한다.

## 0.3.36 · 제출 파일명의 Unicode 비교

업로드 완료 응답의 파일명과 최종 POST에서 복제된 첨부의 이름은 Unicode NFC로 정규화한 값끼리 비교한다. macOS에서 선택한 한글 이름이 NFD이고 학교 응답이 NFC인 경우처럼 표기만 같은 이름을 지원한다. 원래 선택 이름·초기화 필드·multipart 파일명·파일 바이트는 바꾸지 않는다. NFC 외의 대소문자 변환·공백 제거·호환 문자 변환·중복 이름의 번호 제거는 하지 않으므로 다른 파일명은 계속 거절한다.

여러 파일을 고를 때는 각 파일명의 문법을 먼저 검증한 뒤 NFC로 비교해 중복 이름을 거절한다. NFC/NFD로만 다른 두 선택 파일이 모호한 첨부 후보가 되지 않도록 `beforeUpload`와 첫 학교 쓰기 전에 `conditions/not_sent`로 중단한다.

업로드 크기는 정확한 바이트 수와 같아야 한다. 복제 첨부는 같은 최종 POST의 본인/과제/새 attempt와 이름·크기를 확인한 뒤 그 응답의 파일 ID를 fresh 본인 제출과 대조한다. 이름이 같다는 이유로 다른 fresh 파일 ID를 성공으로 바꾸지 않는다. 합성 NFC/NFD 회귀의 수정이며 운영 학교 응답의 형태나 기존 `RESULT_UNCONFIRMED` 원인을 확정하지 않는다. 미확정 작업은 기존 이력과 재전송 금지 계약을 유지한다.


## 0.3.36 · native 완료 응답과 고정 진단

공식 Instructure `canvas-lms`의 과거 고정 commit `cbad59a86dac7e927e0f2f22bc29b6af2177c92e`에서 [완료 controller](https://github.com/instructure/canvas-lms/blob/cbad59a86dac7e927e0f2f22bc29b6af2177c92e/app/controllers/files_controller.rb#L960-L1013)는 파일을 available로 바꾼 뒤 native session에 `as_text` JSON을 반환한다. [render 처리](https://github.com/instructure/canvas-lms/blob/cbad59a86dac7e927e0f2f22bc29b6af2177c92e/app/controllers/application_controller.rb#L2245-L2265)는 이를 HTML 콘텐츠 유형으로 보낸다. SDK가 본문을 읽기 전에 `application/json`만 요구하면 유효한 완료 응답을 거절한다. 이 공식 소스의 구현은 복사하지 않았다. [현재 공식 파일 업로드 계약](https://developerdocs.instructure.com/services/canvas/basics/file.file_uploads)도 업로드와 완료 단계를 구분한다.

같은 Canvas·정확한 `/api/v1/files/:id/create_success`·허용된 발급 쿼리를 검증한 완료 GET 응답에서만 `text/html`의 유효한 JSON을 지원한다. UTF-8 fatal decode, 전체 본문의 `JSON.parse`, 객체·ID·정확한 크기·canonical 파일명 검증을 그대로 적용한다. 반환 파일 ID는 완료 경로의 ID와 정확히 같아야 한다. HTML에서 JSON을 추출하거나 스크립트를 실행하지 않는다. `text/plain`, HTML 문서·script·textarea wrapper, XSSI 접두사, 잘못된 UTF-8·다른 ID·이름·크기는 거절한다. 초기화·receiver 직접 응답·최종 제출의 JSON 콘텐츠 유형 계약은 유지한다.

같은 과거 소스의 [XSSI 조건](https://github.com/instructure/canvas-lms/blob/cbad59a86dac7e927e0f2f22bc29b6af2177c92e/app/controllers/application_controller.rb#L2186-L2189)은 native GET의 `Accept`에 `application/json`이 없을 때 적용된다. SDK 완료 GET은 이미 이 Accept를 보내므로 `X-Requested-With` 누락을 접두사 원인으로 단정하지 않는다. 접두사를 제거하는 파서나 헤더 변경은 추가하지 않는다.

`SchoolAssignmentWriteError.uploadStep`은 `prepare`, `initialize_request`, `initialize_response`, `receiver_request`, `completion_target`, `completion_request`, `completion_response`, `metadata` 또는 `null`이다. `prepare`는 업로드 hook/대상 준비, `initialize_response`는 초기화 JSON·발급 URL/필드 검증, `completion_target`은 완료 redirect 검증, `completion_response`는 완료 JSON 해석, `metadata`는 ID·이름·크기와 복수 업로드 ID 중복 검증을 나타낸다. 기존 3개 인자 생성은 유지하고 추가 인자가 없으면 null이다. 이 값은 파일명·URL·응답·토큰·cause를 담지 않는다.

`finalSubmissionMayHaveWritten`은 업로드 단계에서 false다. 파일 업로드가 학교에 기록됐을 가능성과 과제 최종 제출 가능성을 구분한다. `submit/unknown` 또는 `verify`에서는 true이고 그 외는 false다. Backend는 이 고정 경계를 소유자·실행권·종료 근거와 함께 영속 저장해야 하며, 과거 기록에 이 필드가 없다는 이유로 과거 최종 제출이 없었다고 추정하지 않는다. 이 필드는 학교 전송의 재시도나 미확정 작업 자동 해제 권한을 주지 않는다.

네트워크 요청 수·쿠키/CSRF 범위·최종 전송 직전 fresh 조건 검증·hook·시간/크기 제한·재전송 금지는 유지한다. 같은 합성 완료 응답이 이전 후보에서 `upload/unknown/unexpected_response`로 실패하고 수정 뒤 정상 파일 ID를 반환하는 회귀와, canonical 이름·복제 첨부·fresh 제출 확인의 전체 합성 흐름을 검증했다. 현재 학교의 서버 버전·과거 실패 응답이 이 소스와 같다는 근거는 없으며, 이미 제출한 학교 과제는 이 검증에서 읽거나 변경하지 않는다. 실제 학교의 새로운 ALMS 업로드·최종 제출 성공은 별도 지정 제출물의 QA가 필요하다.
