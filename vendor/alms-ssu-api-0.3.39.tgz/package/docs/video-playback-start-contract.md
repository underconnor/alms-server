# 명시적인 학교 진도 시작 · 0.3.31

0.3.39의 Readystream은 새 start binding에 사용하는 해당 launch 자체의 단일 UPF 검증이 먼저 필요하다. 다른 launch의 검증을 승계하지 않는다. 아래의 사람 확인·일회권·fresh 대상/권한·baseline·ACK 조건은 유지한다. [Readystream 계약](readystream-video-contract.md)

일반 보고와 독립된 학교 쓰기다. 원본 학교 player의 `requestCancelApi`는 사용자 확인 뒤 `state:3`과 `force_cancel:true`를 보낸다. 다른 기기·콘텐츠의 진도 기록이 중단될 수 있다. 일반 거부만으로 동시 수강을 확정하지 않는다.

## 발급과 호출

`createSchoolVideoPlaybackStartController(binding, options)`는 학교 발급 callback binding, `confirmation:'user_confirmed'`, 일시정지된 native 관측과 현재 실행권/학교 읽기 callback을 받는다. `startSchoolVideoPlayback(controller, transport)`는 정확한 대상의 fresh 읽기와 권한 재검증 뒤 별도 opaque request를 한 번 전송한다. `SchoolHttpClient.startVideoPlayback`은 이 request와 controller가 발급한 동일 AbortSignal만 수락한다. 일반 `forwardVideoReport`로 전달하면 거부한다.

Backend는 실제 사람의 확인·짧은 nonce·본인·학교 세대·대상·공용 실행 잠금/임대를 검증한다. SDK의 confirmation literal은 이 검증을 대신하지 않는다. 예약·백그라운드 실행·이전 거부는 사용자 확인으로 취급하지 않는다. 클라이언트로부터 원래 report URL·learner·누적 진도를 받지 않는다.

관측 필드는 `positionSeconds`, `durationSeconds`, `playbackRate`, `paused`, `ended`, `seeking`, `visible`이다. paused/visible true·1배속·ended/seeking false와 학교 길이 일치를 확인한다. 위치는 학교 baseline+0.25초 및 길이 안으로 제한한다. 여분 필드와 `cumulativeSeconds`는 거부한다. 확인권은 controller 발급에서 120초 미만이며 한 번 사용한다. 같은 controller의 동시 호출도 두 번째 전송을 만들지 않는다.

학교 발급 `endat`와 활동의 progressSeconds가 같아야 한다. 전송 전 fresh 결과의 정확한 course/module/item·학교 공개/열림/진도 조건·duration·baseline을 다시 확인한다. baseline은 0~duration, duration은 0초 초과~4시간이다. 누락·변경은 쓰기 전에 거부한다. caller가 같은 identity/generation을 fresh 읽기로 결합해야 한다.

## 별도 요청과 응답

학교가 발급한 HTTPS Canvas progress target과 user/content/type·section/component를 그대로 유지한다. 고정 state 3, 학교 duration, native currentTime과 발급 baseline을 각각 0.001초로 반올림한 cumulativeTime, movie의 page/totalpage 0·cumulativePage 빈 문자열, force_cancel true·단일 JSONP callback만 구성한다. GET이지만 학교 상태를 바꾸는 동작이며 prefetch하지 않는다.

별도 request는 private WeakMap에 보관하고 URL·callback·learner를 JSON/inspect에 노출하지 않는다. 계정별 jar의 target 쿠키만 전달하고 SSO 반환 artifact/Bearer를 추가하지 않는다. redirect는 거부하고 전송은 최대 15초, 응답은 16KiB, 전체 검증/읽기는 90초로 제한한다. 시작 ACK는 실행 없이 정확한 JSONP wrapper·JSON plain object·strict boolean `result:true`·own `error_code`를 검증한다. 시작의 `error_code` 값은 승인 조건에 사용하거나 저장하지 않는다. 일반 진도 보고 ACK는 기존 `result:true,error_code:null` 조건을 유지한다. false 응답과 형식 오류의 고정 실패 분류를 유지한다.

전송 뒤 fresh 학교 결과를 읽고 일회 controller를 종료한다. 결과는 `{transport:'acknowledged'|'unknown', school}`이며 ACK를 완료·출석 인정으로 해석하지 않는다. 실패/유실/timeout은 재전송하지 않는다. 쓰기 가능성 뒤 후속 검증이 실패하면 `SchoolVideoPlaybackStartError`의 고정 stage·mayHaveWritten true와 needs_verification을 보존한다. 이 controller는 기존 실패 보고·job·학교 이력을 수정하거나 새 일반 수강 수명을 자동으로 시작하지 않는다.

## 근거와 남은 실제 검증

공개 custom script는 SHA-256 `7e6153460179083c25bc9263b76a69d1189b669e870bb5393d81cb4ee5a80a15`, 23,477바이트다. 451줄 requestCancelApi의 runtime current/cumulative·0.001초 반올림·force_cancel/state 3과 POST+JSONP 선언을 확인했다. 기존 v29 실제 wire 관찰은 사용자 확인 뒤 GET/state 3/force_cancel true/HTTP 200/ACK이었다. 실제 GET과 정적 POST 선언을 구분한다. 원문 스크립트를 저장하거나 실행하지 않았다.

## 0.3.32 · 명시적 시작 ACK 분리

2026-10-13의 익명 정적 GET 한 번은 200·23,477바이트였고 위 기존 SHA와 일치했다. AST에서 `callbackCheckDuplicate`는 401줄에 선언되고 403줄의 `!response.result`로 분기한다. 이 함수의 직접 `error_code` property 참조는 0이며, false 처리 안에는 405줄 Pause와 415줄 requestCancelApi·417줄 Play 호출이 있다. `callbackCheckIllegalPlay`의 433줄 result 거부 분기 아래에서 435줄 오류 코드 분기가 있다. 451줄 `requestCancelApi` 선언 내부의 직접 result/error_code property 참조는 각각 0이었다. 원문은 저장·실행하지 않았고 정확한 success callback 인자 전달 구조는 이번 정제 AST 출력에 보존하지 않았다. 이 정적 사실을 응답의 모든 필드 의미나 실제 동시 수강 원인의 증명으로 확대하지 않는다.

같은 날 운영의 명시적 시작 한 번은 `ack_error_code` 진단을 남겼다. 기존 파서상 strict boolean result true·own error_code가 존재하고 그 값이 null 이외였다는 뜻이다. 실제 오류 코드 값·타입은 보관하지 않아 특정 오류 의미를 추정하지 않는다. 이 시작에 일반 보고의 null 오류 코드 제약을 공용 적용했던 것을 분리한다. 정확한 wrapper·JSON·plain object·boolean result·own field, false/invalidpbrate 거부는 유지하고, 별도 시작의 true 응답에서만 오류 코드 값을 승인 조건에 사용하지 않는다.

승인은 학교 진도 기록의 시작 응답 범위다. 이후 fresh 읽기의 권한·대상·학교 결과 검증, 단일 전송과 controller 종료, 유실/timeout/거부 재전송 금지를 유지한다. ACK를 학습 완료·출석 인정으로 바꾸거나 기존 중단 작업을 복원하지 않는다. 합성 null/non-null ACK 비교는 일반 보고의 strict null 조건과 시작의 제한된 차이를 검증한다. 이 후보의 실제 학교 시작·일반 수강 성공·배포는 통합 담당자의 별도 QA다.

[정제된 회귀·정적 근거](evidence/video-playback-start-ack-regression.json)

SDK 로컬 검사는 합성 데이터만 사용한다. 실제 계정의 새 확인 동작·학교 응답·다른 콘텐츠 영향·학교 진도/출결·배포는 통합 담당자가 별도로 검증한다. 새 실제 성공이나 과거 거부의 원인 해결을 주장하지 않는다.
