# 영상 상세와 내부 launch 후보 · v17

0.3.39의 정확한 Readystream 단일 UPF 경로와 launch별 private 검증은 [별도 계약](readystream-video-contract.md)을 따른다. 기존 movie 경로·보고 상한·재전송 금지와 아래 당시 근거는 유지한다.

## 진도 단위 근거

2026-10-01 UTC에 학교 화면이 이미 참조한 공개 [LearningX commons.js 4.82.9](https://canvas.ssu.ac.kr/learningx/js/commons.js?version=4.82.9)를 다시 읽었다. 원본 JS는 저장소에 포함하지 않는다. 응답은 3,472,965 bytes이며 SHA-256은 `9b7ef1f7fd3ba3254c1751ace3f1550a04f3b63fd5b8b82bf7d500e0ca8ddf0e`로 이전 조사와 같다.

- 모듈 `89568`의 영상 진도 컴포넌트는 `attendance_data.progress`를 초 단위 시간 문자열로 바꾼다. 비율은 `progress / item_content_data.duration * 100`이다.
- 영상 메타데이터는 `item_content_data.duration`을 초 단위 시각으로 표시한다.
- 모듈 `93613`의 출석 이력 표시는 `last_at`과 `progress`를 초 단위로 표시하고 각각 duration으로 나누어 비율을 구한다.
- 학교 화면의 99% 초과 → 100% 표시는 표시 보정이다. 이 라이브러리는 0–100 범위의 실제 비율을 반환하며 출석 상태를 바꾸지 않는다.

이 근거는 학교의 배포 코드가 해석하는 **단위와 표시 계약**이다. 학생 영상 재생·진도 전송·시청 후 출석 갱신을 검증한 것은 아니다.

| 공개 필드 | movie | pdf/file |
| --- | --- | --- |
| `durationSeconds` | 유한한 비음수 duration | null |
| `attendance.progressSeconds` | 유한한 비음수 progress | null |
| `attendance.lastPositionSeconds` | 유한한 비음수 last_at | null |
| `attendance.progressPercent` | duration > 0일 때 progress/duration × 100, 최대 100 | null |

학교 원문 필드인 `durationValue`, `progressValue`, `lastPositionValue`는 호환성을 위해 그대로 제공한다. 알 수 없는 값은 0으로 만들지 않는다. `completed`, `status`, `useAttendance`는 서로 별개인 학교 값으로 유지한다.

## 원문 launch의 내부 전달

`moduleActivityVideoLaunch(courseId, moduleItemId)`는 본인 강좌 소유권을 확인한 Backend만 호출한다. 모듈 안의 실제 attendance item ID를 찾아 같은 강좌·활동의 상세를 재조회한다. `movie`·공개·열림 조건과 콘텐츠 ID에 결합된 Commons HTTPS 경로를 검사한다. SchoolHttpClient의 토큰 범위와 host 목록은 바뀌지 않는다.

원문 viewer는 WeakMap에만 보관한다. JSON과 일반 Node inspection에는 종류만 표시한다. `inspectSchoolVideoLaunch()`는 서버의 제한된 loader를 위한 명시적 accessor이며 결과를 공개 응답·DB·로그에 보내면 안 된다. 반환 metadata는 새 파싱 결과이며 freeze한다. 임의 객체로 accessor를 호출하면 정규화 오류다.

`callbackVerified:false` 상태에서는 query와 callback의 의미를 검증했다고 주장하지 않는다. 원문 viewer 보존은 실행 승인이 아니다. 이 launch 메서드는 Commons page, media, callback, heartbeat를 요청하거나 player를 실행하지 않는다. 미디어·보고 경로는 선택한 실제 영상 응답과 별도 검증해야 한다.

## 0.3.4 개발 당시 실측 경계

v17 조사 당시 운영의 저장된 LMS 교환 상태는 실패였고, `/mypage`는 200이지만 학교가 반환한 Canvas dashboard는 500이었다. 동일한 저장 세션의 본인 user-scoped terms도 인증 오류로 끝났다. 이 때문에 해당 영상의 viewer HTML/XML·media/callback 실측은 새 정상 인증 후 이어서 진행한다. 조사 중 원본 학교 응답이나 세션을 저장하지 않았고 학교 재생·진도·제출 요청은 0건이다.

합성 회귀는 상세의 단위·null/0·범위·완료 분리, source의 ID 불일치·잠금·잘못된 URL·원문 노출 방지, 모듈 기반 GET만 수행함을 검사한다. 실제 재생 가용성의 근거로 사용하지 않는다.

## 0.3.5 · 출석 비대상 MP4 원본 해석

2026-10-02 01:04 KST에 새 LearningX 세션의 본인 신원·소유 모듈을 확인하고, 출석 비대상 참고 영상의 HTML/XML에 새 resolver를 적용했다. Native Canvas 로그인 폼 처리는 아직 실패하지만 LearningX 조회와 이번 원본 해석은 성공했다. 앞 절의 조회 실패는 0.3.4 개발 당시 기록이다.

```ts
const launch = await client.moduleActivityVideoLaunch(courseId, moduleItemId);
const media = await resolveSchoolVideoMedia(launch, undefined, {signal});
const privateData = inspectSchoolVideoMedia(media); // server only
// {detail, contentId, mediaUrl, mimeType:'video/mp4', delivery:'progressive',
//  useAttendance:false, callbackVerified:false}
```

호출자는 강좌 소유권을 먼저 확인하고 결과 사용 전에 현재 사용자·학교 세대·공개/열림 상태를 다시 검증한다. 이 라이브러리는 ALMS 세션·DB·만료 정책을 관리하지 않는다. `media`의 JSON과 Node inspection에는 종류만 나오며 실제 주소는 WeakMap 내부에만 있다. accessor 결과를 브라우저·DB·로그에 보내지 않는다.

0.3.5 당시 resolver는 `useAttendance === false`만 받았다. true 또는 null이면 HTTP 전에 `unsupported`를 반환했다. 이 제한의 0.3.17 변경은 아래에 따로 기록한다. 여러 story·HLS·DRM·다른 저장소 배치·Flash pseudo 재생은 지원하지 않는다. `callbackVerified:false`를 유지하며 영상 종료나 원본 주소 확인을 출석·학습 완료로 바꾸지 않는다.

### 확인한 구조와 요청 경계

- 기존 launch가 공개/열림 movie와 같은 콘텐츠 ID를 검증한다. resolver는 HTML의 단일 `var contentUri` literal을 읽는다. 실제 페이지의 정확한 루트 상대 경로 또는 동일한 절대 경로만 허용한다.
- `content.php?content_id=...` XML의 콘텐츠 ID·`video1`·단일 desktop/html5 `progressive` 경로를 대조한다. `content_uri`는 `/contents31/ssu1000001/:contentId/contents/`로 제한한다.
- 미디어는 관찰한 `ssuin-object.commonscdn.com`의 `/ssu-contents` + 같은 콘텐츠 경로 + `media_files/mobile/:filename.mp4`만 허용한다. 다른 호스트·포트·userinfo·query·fragment·경로 이탈·percent 인코딩은 거부한다. XML entity/DOCTYPE과 중복 필드도 거부한다.
- `SchoolHttpClient.getCommonsVideoMetadata()`만 HTML/XML을 익명 GET한다. CookieJar·Bearer·Referer를 보내거나 응답 Cookie를 저장하지 않는다. 일반 `schoolUrl()`의 허용 호스트는 그대로다. 리다이렉트는 거부하고 요청별 최대 15초·2MiB를 적용한다. resolver는 두 번 요청하며 미디어·진도 URL을 호출하거나 스크립트를 실행하지 않는다.

별도 승인된 운영 진단에서 해당 원본의 HEAD는 200·`video/mp4`·619,492,057 bytes였고, `Range: bytes=0-0`은 206·본문 1 byte·`Content-Range: bytes 0-0/619492057`로 확인했다. 두 요청 모두 리다이렉트가 없었고 학교 자격정보를 보내지 않았다. 약 591MiB이므로 Backend는 제한된 Range 스트림을 제공해야 한다. 다른 원본에도 같은 응답을 가정하지 말고 MIME·범위·총량·현재 권한을 검증한다. `mimeType`은 resolver가 지원하는 형식이며 Backend의 실제 응답 검사를 대신하지 않는다.

실제 미디어 본문은 한 바이트만 확인했고 학교 진도·제출 요청과 DB 변경은 없었다. 재생·소리·이어보기·출석 보고는 아직 미검증이다. 이 변경은 이슈 #13의 원본 해석 부분이며 전체 수동/서버 재생 완료를 뜻하지 않는다.

## 0.3.17 · 출석 대상 영상의 수동 원본 해석

2026-10-03. 기본 영상 재생이 숨겨지는 문제를 줄이기 위해 명시적 `useAttendance:true`도 같은 수동 원본 해석 경로에 허용한다. `SchoolVideoMediaData.useAttendance`는 boolean이며 학교 상세의 값을 그대로 보존한다. null·누락·알 수 없는 값은 metadata HTTP 전에 거부한다. 기존 소유권·공개/열림·동일 content·manifest/CDN 경로 제한은 유지한다.

이 경로는 viewer HTML과 content XML을 GET으로 읽고 private media handle을 반환한다. 학교 플레이어 script를 실행하거나 progress callback을 호출하지 않는다. `callbackVerified:false`는 그대로다. 따라서 서비스는 출석 대상 영상의 재생 전에 **현재 이 재생은 학교 진도·출석에 반영되지 않는다**는 안내를 보여줘야 한다. 학교 보고 연결은 P0의 남은 작업이며, 원본 해석 성공이나 media ended를 학교 학습 완료로 바꾸지 않는다.

합성 표본으로 true/false 값 보존, 알 수 없는 설정 거부, metadata GET 두 번만 호출, Cookie/Bearer 누출 없음, media/script/report 요청 없음과 기존 URL·문서 검증을 확인한다. 실제 출석 대상 영상의 구조·재생·학교 보고 검증은 별도 운영 근거로 기록한다.

## 0.3.22 · 관측 기반 영상 보고 후보

이 버전은 원본 학교 플레이어 요청의 서버 전달과 ALMS 수동 영상 관측 adapter를 제공한다. SDK의 합성 검사와 학교 원본 플레이어 관찰을 근거로 구현했으며, **이 SDK를 통한 실제 학교 전송·서비스 배포·출석 전환은 아직 검증하지 않았다.** 기존 source/media의 `callbackVerified:false`와 binding의 `reportingVerified:false`는 유지한다. Backend가 통합 검증을 마치기 전 서비스 capability를 켜지 않는다.

### 확인한 학교 규격

- 학교 발급 callback의 강좌·section·활동·사용자·콘텐츠 결합은 그대로 유지한다. 선택 영상에서 일반 보고는 GET JSONP였고 state=8, 영화 page/totalpage=0, cumulativePage 빈 문자열이었다. 성공 응답은 같은 callback으로 감싼 JSON의 `result:true,error_code:null`이었다. 초기 중복 수강 확인 뒤의 `force_cancel=true` 요청은 일반 보고와 구분하며 이 버전은 강제 취소를 지원하지 않는다.
- 학교 배포 `uni-player.min.js` SHA-256 `33a299812f27eb18c866e33f124e4c7ad1f198eaf822f80e679fce71335acb68`, custom script SHA-256 `7e6153460179083c25bc9263b76a69d1189b669e870bb5393d81cb4ee5a80a15`를 읽기 전용으로 대조했다. 원문을 저장소에 포함하지 않는다. custom script의 state는 playing=3, update=8, unload=99, ended=10, unload_end=100이며 정기 전송 간격은 300,000ms다. 실제 정상 재생 관찰은 update 요청을 확인한 근거이며 모든 상태 전환의 실측으로 확대하지 않는다.
- 라이브러리의 updateCurrentTime은 현재 위치를 cumulative setter에 전달한다. setter는 기존값보다 큰 경우에만 갱신한다. 초기값은 contentEndTime이며 음수 sentinel은 별도 분기다. 따라서 수동 adapter는 발급 `endat`가 0 이상의 숫자이고 새 학교 `attendance.progressSeconds`와 같을 때만 시작한다. 누적값은 이 baseline과 서버 시간 검사를 통과한 연속 위치의 최대값이며 baseline에 재생 시간을 더하지 않는다. 음수/없음/불일치는 지원하지 않는다.
- 일반 JSONP script에 별도 Bearer를 넣지 않는다. 전용 transport는 대상에 맞는 CookieJar 쿠키만 보내고 sToken/sIdno는 제외한다. 실제 브라우저 요청의 Cookie 유무는 아직 확인하지 못했으며 SDK의 이 전송 선택은 운영 QA가 필요하다.

### 호출 계약

1. 호출자가 새 native 신원·강좌 소유권·모듈과 상세·열림/공개/보고 가능 상태를 확인한 launch로 binding을 만든다. ALMS 로그인 세션·학교 generation·사용자별 실행 nonce와 API/worker 공용 lease는 Backend 책임이다.
2. 원본 school player runtime은 `createSchoolVideoReportController` → `observeSchoolVideoPlayback` → 실제 URL을 받는 `prepareSchoolVideoReportRequest` → `forwardSchoolVideoPlayerRequest`를 사용한다. 원본 URL을 임의로 고치거나 추측한 query를 추가하지 않는다. 서버에서 직접 관찰하는 runtime의 관측 공백은 1.5초까지다.
3. ALMS 수동 video는 별도 `createSchoolManualVideoReportController` → `observeSchoolManualVideoPlayback` → `reportSchoolManualVideoPlayback`를 사용한다. 이 경로는 원본 요청 전달과 다르게 관측값으로 보고를 구성한다. 클라이언트가 누적값을 보내면 거부한다. 최초 관측은 학교 baseline + 0.25초 이내로 제한하고 첫 누적값은 학교 baseline 그대로 유지한다. metadata 준비 직후 pause까지의 작은 실제 위치 차이를 허용하며 이미 진행한 재생을 역산하지 않는다. 이후에는 가시성·1배속·연속 위치·pause/seek·서버 경과시간을 검사한다. 관측 공백은 15초까지이며 종료 뒤에는 새 binding이 필요하다. Backend는 요청마다 세션/대상/nonce를 검증하고 Front는 원본 media 이벤트를 전달해야 한다. 클라이언트 관측은 출석 증명이 아니다.
4. `validateCurrent(signal)`은 전송 전에 현재 사용자·generation·lease와 fresh 학교 권한을 확인해야 한다. 보고 중 DB 트랜잭션을 오래 잡지 않는다. `readFresh(signal)`은 보고 뒤 새 학교 상태를 읽어야 하며 오래된 캐시 timestamp, 다른 대상, 추정 recognized 값을 반환하면 거부한다.
5. transport는 실제 전송 전 controller가 지정한 1회 permit과 동일 AbortSignal을 요구한다. HTTPS 발급 경로·고정 query·단일 callback만 허용하고 redirect/force_cancel/중복 필드/불명확 값은 거부한다. 요청은 최대 15초·응답 16KiB·전체 보고/재조회 90초이며 자동 재전송하지 않는다. JSONP를 실행하지 않고 정확한 wrapper 안 JSON만 파싱한다.
6. ACK 뒤에도 fresh 학교 조회를 마쳐야 결과를 반환한다. ACK 유실·거절·비정상 응답은 `transport:'unknown'`과 fresh 결과를 반환하고 controller를 닫는다. fresh 조회도 실패하면 고정 `SchoolVideoReportError.stage`와 `mayHaveWritten:true`를 반환한다. 자동 재시도·성공 추정·다른 수강 강제 중단은 하지 않는다.

수동 adapter와 native controller는 서버 전용 메모리 핸들이다. JSON/inspection에는 종류·고정 상태만 있으며 callback URL·사용자·콘텐츠·nonce·쿠키를 내보내지 않는다. report ACK, 영상 ended, 로컬 실행 종료와 학교 완료/출석 인정은 서로 다른 값이다. `recognized:null`을 유지하며 실제 학교의 `completed`·출석 상태를 새 조회 결과 그대로 사용한다.

## 0.3.30 · 고정 응답 실패 분류

전용 보고 transport가 던진 오류를 SDK controller가 처리하기 전에 `inspectSchoolVideoReportResponseFailure(error)`로 분류 enum만 읽을 수 있다. 기존 SchoolError 코드·직렬화와 `result:true,error_code:null` 승인 조건을 유지하며 반환된 transport·학교 결과·controller 종료·재시도 금지 계약은 바꾸지 않는다. 본문·헤더·callback·URL·학교 식별자·실제 `error_code` 값은 보관하지 않는다.

분류는 `content_type`, `declared_length`, `missing_body`, `body_limit`, `length_mismatch`, `utf8`, `ack_body`, `ack_callback`, `ack_envelope`, `ack_json`, `ack_schema`, `ack_result_rejected`, `ack_invalid_playback_rate`, `ack_error_code`다. 명시적인 거부와 null이 아닌 오류 코드의 존재를 구분한다. 공개 custom script의 기존 SHA-256 `7e6153460179083c25bc9263b76a69d1189b669e870bb5393d81cb4ee5a80a15`를 독립 재대조했고, `result:false`이고 문자열 오류 코드가 대소문자를 무시한 `invalidpbrate`와 정확히 일치할 때만 `ack_invalid_playback_rate`로 분류한다. 이 값은 학교 응답의 주장이다. 실제 재생 속도나 동시 재생 원인을 추정하지 않으며, 다른 false 응답은 `ack_result_rejected`로 유지한다. 인식하지 못한 오류는 null이며 caller가 임의 객체에 넣은 분류값도 읽지 않는다. 진단은 package-private WeakMap에만 저장해 기존 오류 JSON에 새로운 필드를 넣지 않는다.

학교 응답을 다시 받아 분류를 복원하려고 보고를 재전송하지 않는다. 과거 운영 로그에 없는 분류는 이후 최신 학교 조회로도 확정할 수 없다. 이 버전의 근거는 합성 응답 검사이며 실제 학교 거부 원인의 확정과 배포는 별도 검증한다.

## 0.3.28 · contents29 video1 저장 형식

2026-10-08 운영 읽기 조사에서 본인 신원·수강권한·발급 launch와 익명 viewer/manifest를 8 GET/모두 200으로 확인했다. manifest는 단일 `video1`이며, 발급 `content_uri`가 같은 콘텐츠의 정확한 `https://commons.ssu.ac.kr/contents29/ssu1000001/:contentId/contents/` 형식이었다. 선택 desktop/html5의 `progressive` MP4도 같은 콘텐츠의 CDN `media_files/mobile` 경로에 결합되어 있었다. 기존 contents31 root 조건에서 resolver가 `forbidden_target`을 반환했고 CDN·학교 보고·재생 요청은 시작하지 않았다. 조사 중 DB·영속 jar·학교 데이터 쓰기는 0이었다. 실제 식별자·발급 URL·파일명·본문·인증 자료는 저장소에 보관하지 않는다.

0.3.28은 기존 `video1` root에 위 contents29 형식 하나만 추가한다. contents31과 contents29 두 exact root를 허용하며, 선택 MP4의 CDN prefix는 검증한 root의 pathname에서 대조한다. `contents` 뒤의 임의 숫자를 허용하지 않고, 다른 콘텐츠/tenant/host·query/fragment·인코딩/경로 이탈·중첩 파일은 계속 거부한다. desktop/html5 선택이 실패했을 때 mobile/flash 등 다른 항목으로 대체하지 않는다. UPF의 단일 story·media ID·duration·발급 template 대조는 변경하지 않는다.

합성 회귀는 movie/mp4와 출석 대상/비대상에서 익명 metadata GET 두 번만 발생하는 성공, private handle 비노출과 위 confinement 실패를 확인한다. 새 media 바이트·보고 callback·재생·진도/출석 인정은 이 검사에 포함하지 않는다. 라이브러리 후보의 학교 적용·Backend 스트리머 허용 경로·운영 배포·브라우저 재생 결과는 각각 별도 완료 조건이다.

## 0.3.37 · 수동 관측의 선택적 monotonic 타이밍

수동 브라우저 관측은 5초 간격으로 만들어져도 HTTP 도착 간격이 그보다 짧아질 수 있다. 합성 표본에서 최초 관측은 2.4초 뒤, 다음 관측은 생성 후 0.3초 뒤 도착하면 실제 위치와 관측 시각은 5초 증가하지만 서버 도착 간격은 2.9초다. 기존 서버 구간 + 1초 검사는 이 정상 표본을 거절한다. 이 절은 그 경합을 재현한 SDK 후보의 계약이며 과거 운영 오류 전체의 원인 확정이나 새 실제 학교 수강 성공을 뜻하지 않는다.

### 협상과 모드 고정

`SCHOOL_MANUAL_VIDEO_OBSERVATION_TIMING`과 실제 SDK 수동 handle의 `inspectSchoolManualVideoReportController(handle).observationTiming`은 모두 `client_monotonic_v1`이다. Backend는 설치된 SDK와 이번에 준비한 실제 handle의 지원을 확인한 경우에만 Front에 이 모드를 광고한다. 구버전·원본 native runtime·명시적 학교 새 시작에 이 필드를 추가하지 않는다.

협상한 Front는 같은 동기 실행에서 native media snapshot과 `performance.now()`를 읽어 `SchoolManualVideoObservation.capturedAtMs`에 넣는다. 값은 유한한 숫자이고 0 이상 `Number.MAX_SAFE_INTEGER` 이하여야 한다. 0·소수·동률은 가능하며 명시적 undefined/null/문자열·NaN·무한대·역행은 거절한다. 첫 관측의 필드 유무로 모드를 고정하고 이후 추가·제거·혼용을 거절한다. 필드 없는 기존 수동 호출과 원본 native runtime은 기존 서버 시간 검사를 그대로 사용한다.

### 고정 시간 한도

밀리초 단위로 controller 생성 시각을 `s`, 첫 수신/관측 시각을 `r0/c0`, 현재 수신/관측 시각을 `ri/ci`로 둔다. `R=ri−r0`, `C=ci−c0`, `U=min(r0−s,5000)`이다. `U`는 최초 snapshot이 전송 중이었을 불확실성의 상한으로 한 번만 고정한다. 이후 pause·buffering·느린 응답은 이 한도를 새로 적립하거나 anchor를 옮기지 않는다.

- 수신과 관측 clock은 각각 역행할 수 없다. 두 clock의 연속 관측 간격은 각각 15초 이하여야 한다.
- 전체 client elapsed는 `C <= R+U+1000`을 만족해야 한다. 고정 첫 anchor의 residual `|R−C| <= 5000`과 매 구간의 `|Δr−Δc| <= 5000`도 모두 검사한다. 5초보다 큰 도착/관측 간격 차이는 안전하게 중단한다.
- 위치와 누적값의 구간 증가는 각각 `Δc/1000 + 1초` 이하다. 위치와 누적값의 전체 증가는 각각 서버 전체 한도 `(R+U)/1000 + 1초`와 별도 client 활성시간 + 1초를 모두 만족해야 한다.
- client 활성시간에는 이전 관측이 paused 또는 ended인 구간을 넣지 않는다. 그런 구간은 기존 1초 위치 오차만 허용한다. paused 준비 직후 실제 playing 이벤트까지의 0.1–0.2초는 허용하되 반복 오차는 전체 한도에 걸리므로 관측마다 새 시청 시간이 생기지 않는다.
- 최초 위치는 기존 학교 baseline + 0.25초 이내이며 첫 누적값은 학교 baseline이다. 이후 누적값은 연속 실제 위치의 최대값으로만 갱신한다. baseline이나 client clock에 시청 시간을 더하지 않는다.

공개/열림·정확한 binding·duration·가시성·1배속·seek 금지, Backend의 매 요청 소유/세션/generation/nonce/lease 검증, 보고 freshness·ACK·fresh 학교 결과 조건은 유지한다. 학교 request query에는 `capturedAtMs`나 협상 필드를 보내지 않는다. 학교 보고 간격·요청 수·재전송 금지·종료 동작도 바꾸지 않는다.

### 신뢰의 한계와 오류 진단

클라이언트 시각과 위치는 인증된 클라이언트가 전달한 관측이며 학교 출석의 증명이 아니다. 예를 들어 최초 전송 불확실성 `U=3초`가 있고 40초 동안 unpaused 상태로 buffering했다면, 실제 1초 뒤 위치와 client clock을 함께 4초 증가시킨 신호는 5초 오차 범위의 정상 지연과 구분되지 않을 수 있다. `capturedAtMs`가 정직하게 1초 증가한 상태에서 위치만 4초 증가하면 거절하며, 실제 1초에 client 10초를 증가시키는 큰 보상·고정 residual 초과·새 pause 시간 적립은 거절한다. Front의 native seek/rate/visibility 이벤트 중단과 서버 한도는 유지하지만 임의 클라이언트의 관측을 암호학적으로 증명하지는 않는다.

`inspectSchoolVideoObservationFailure(error)`는 SDK가 이번에 만든 오류에만 `{kind}`를 반환하고 그 외에는 null이다. 오류는 기존 `unsupported`/`unexpected_response` 코드와 controller 종료를 유지한다. core가 `SchoolVideoReportError`로 정규화한 validation 오류와 수동 wrapper의 close 뒤에도 같은 분류를 읽을 수 있다. 분류는 내부 WeakMap에만 있으며 원본 관측·clock·target·URL·학생 정보·cause를 저장하지 않는다.

고정 kind는 `playback_shape`, `visibility`, `client_cumulative`, `initial_position`, `initial_baseline`, `duration`, `server_clock`, `timing_value`, `timing_mode`, `client_clock_reverse`, `observation_gap`, `client_clock_ahead`, `clock_residual`, `pair_clock_drift`, `position_reverse`, `pair_progress`, `inactive_progress`, `lifetime_server_progress`, `lifetime_client_progress`다. 과거 오류는 소급 분류하지 않는다. Backend의 API 오류 응답/분석 계약은 별도로 검증하며 여기서 원본 error를 공개하지 않는다.

합성 회귀는 정상 수신 지연·늦은 첫 playing/paused·초기 오차 상한·40초 buffering 뒤 10/1초 위조·slow clock 보상·구간/전체 drift·양쪽 15초 공백·timing 혼용/역행/잘못된 값·paused/ended·seek/rate/visibility·반복 오차 가산·진단 비노출과 기존 native/legacy 결과를 검사한다. 합성 성공은 배포, 브라우저 5분 보고/ended, fresh 학교 진도·학습 완료·출결·인정 전환을 대신하지 않는다.
