# Fresh learning status · 0.3.16 candidate

0.3.39 adds canonical `readystream` to the exact Commons module/detail relationship. Its measured duration/progress/last-position values use seconds, while its resource type remains `readystream`. The existing five-GET identity/ownership and status/recognition rules below remain. Read-only status does not grant a playback/report capability; the separate single-video UPF validation is required. See [Readystream contract](readystream-video-contract.md). The original version's scope follows below.

`LearningxClient.moduleLearningStatus(courseId, moduleItemId, signal?)` reads one current school activity without an ALMS result cache. This is a read contract for later job verification. It does not start a player, report progress, acknowledge material views, retry a failed request, or change an ALMS job.

## Identity and scope

The caller constructs the client from a verified LearningX bootstrap and that same person's private school jar. Each call independently performs these five JSON GETs:

1. Native `/api/v1/users/self/profile`: both user ID and login must match the bootstrap.
2. LearningX user-scoped `terms?include_invited_course_contained=true`.
3. `learn_activities/courses` for the school's default terms. If none is marked default, retain the existing school-dashboard rule of selecting the first returned term; do not infer a term from today's date. Empty terms, a non-owned course, duplicate IDs, or a catalog from other terms fail.
4. The owned course's `modules?include_detail=true`: resolve exactly one requested module item to its actual attendance item ID. Only Commons `movie`, `pdf`, and `file` activities are supported.
5. That course's exact `attendance_items/:itemId`: recheck course ID, item ID and resource type. A content ID supplied by the module must also match the detail.

No assignment/module ID is inferred. No arbitrary URL, report, launch, media or other user's route is accepted by `readLearningStatusJson`. Existing generic HTTP, calendar and assignment purpose rules are unchanged. Native GETs receive scoped Canvas cookies without LearningX Bearer, `xn_api_token`, `sToken` or `sIdno`; LearningX Bearer remains confined to `/learningx/`. Normal school cookie renewal is confined to the same person's in-memory jar. Backend owns any later session persistence and generation checks.

## Result semantics

The DTO contains course/module/item IDs, the final SDK observation time, resource type, nullable `published`, `opened`, `useAttendance`, `omitProgress`, `completed`, normalized `schoolAttendanceStatus`, and nullable movie progress/duration values. It omits names, titles, descriptions, file names, content IDs, viewers, signed URLs and authentication data. IDs are private service data, not analytics or log attributes.

- `recognized` is always `null`. No explicit school recognition contract has been verified for this method. Neither `completed`, a school status label, 95/100 percent nor the end of a media stream establishes recognition.
- Only `useAttendance === false` produces `attendance: 'not_applicable'`. True, absent and null produce `'unknown'`.
- Known school labels are `attendance`, `absent`, `late`, and `none`. Other well-formed labels become `unknown`; absent/null remains null. A label is not a verified recognition decision.
- Movie `duration`, `attendance_data.progress`, and `last_at` are seconds. The display ratio is `min(100, progress / duration * 100)` only when duration is positive and both values exist. PDF/file progress is not assigned video units or a ratio.
- Missing/null optional values remain null; actual zero/false is preserved. Invalid present flags, quantities, status syntax or malformed required structures fail. An absent attendance object means unknown fields, not a completed or empty-success claim.
- Closed or unpublished metadata can be read. These flags do not authorize playback or reporting.
- `observedAt` is the SDK completion time after the final read and cancellation check, not a school change timestamp or proof of cache freshness inside the school's own infrastructure.

## Bounds and failure

All five requests share the caller signal and a 60-second overall deadline. Each HTTP operation is bounded to 15 seconds (or a lower configured limit), 2 MiB and JSON HTTP 200, with manual redirects and fetch `cache: 'no-store'`. Late responses and stalled streams are cancelled even when a transport ignores abort. Total response bytes are capped at 8 MiB, with at most 30 terms, 100 courses, 200 modules and 5,000 module items. These unpaginated endpoints must not return a nonempty Link header; unsupported pagination fails rather than returning partial state.

401/403 becomes `authentication_required`; native identity mismatch becomes `identity_mismatch`; unauthorized targets/bindings become `forbidden_target` (the existing module resolver retains `unexpected_response` for malformed course binding); malformed structures become `unexpected_response`; unsupported types/bounds become `unsupported`; cancellation, timeouts and transport failures become retryable `upstream_unavailable`. There are no automatic retries. Exceptions carry no raw response, URL, credential or cause.

Backend must bypass both activity and job-result caches, check current ALMS identity and school generation before and after this call, and verify that the requested job still binds the same course/module. This SDK does not save a job result or set success. A caller deadline must also include any Backend queue/connector work that precedes the SDK method.

## Evidence and limits

Endpoints and the movie seconds/display contract come from the existing school-scoped module/detail implementation and the public deployed LearningX component documented in [video-progress-contract.md](video-progress-contract.md). Prior real reads and synthetic parser tests do not establish the meaning of recognition or a server playback/report contract. This candidate has only synthetic tests until the integration owner performs a separate school read QA. Player/report callbacks, worker activation, pause/resume, automatic retries and attendance recognition remain outside this change.
