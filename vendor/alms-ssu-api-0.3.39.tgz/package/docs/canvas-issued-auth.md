# Canvas 발급 로그인 폼 처리

## 0.3.8에서 달라지는 처리

`parseCanvasIssuedLogin`은 학교가 제시한 HTTPS Canvas 응답의 POST action을 정확한 `https://canvas.ssu.ac.kr/login/canvas`와 대조한다. form과 literal `window.loginCryption` 호출이 각각 하나여야 하고, 사용자 필드가 있으면 이미 검증할 예정인 callback 식별자와 일치해야 한다. RSA 발급 자료는 메모리에서만 복호화하며 JavaScript를 실행하지 않는다.

`/learningx/login/from_cc` 응답에서 `authenticity_token` input이 아예 없으면 `authenticityToken:null`을 반환한다. 이때 POST body에서 그 키를 생략한다. 필드가 하나라도 존재하면 비어 있지 않고 공백만이 아니며 4,096자 이내여야 한다. 중복 필드, 중복 사용자 필드, 일반 `/login/canvas` 또는 다른 페이지의 CSRF 누락은 거부한다. 필드 값에 trim·decode·추정값 대입을 하지 않는다.

이 변경은 학교 서버의 CSRF 검사를 해제하지 않는다. 학교가 발급한 form의 부재를 그대로 전송하고, 학교의 로그인 응답·세션·신원 검증을 계속 요구한다. 인증 폼 이외의 제출·학습 요청에는 적용하지 않는다. 학교 ID·비밀번호를 사용자에게 직접 받는 기능도 추가하지 않는다.

## 근거와 아직 검증하지 않은 부분

2026-10-02 기존 본인 Backend 세션에서 보존된 진단은 `canvas_form / unexpected_response / csrf_shape`였다. 해당 frame은 HTTP 200, form 1개, inline script 1개, 정확한 Canvas POST action과 loginCryption 존재, LearningX 토큰 존재, native Canvas 세션 쿠키 부재였다. 현재 LearningX 신원과 소유 강좌 읽기는 성공했지만 native 강좌 GET은 학교 discovery 로그인으로 이동했다.

이 진단은 CSRF 검사 단계가 실패했다는 근거다. 기존 9개 reason만으로 누락·빈 값·중복을 구분하지는 못한다. 기존 callback artifact를 공식 certificate 경로에서 한 번 다시 읽었으나 학교가 인증 실패 페이지로 거부했다. 그 artifact를 반복 호출하거나 새 발급 응답인 것처럼 사용하지 않는다.

[LMS-API의 해당 처리](https://github.com/chlwhdtn03/LMS-API/blob/34c5d9d1e12717b1e0dd8a2745634ce95b270ff9/library/src/commonMain/kotlin/io/github/chlwhdtn03/internal/LmsAuthService.kt#L74-L86)는 token을 추출하되 없는 경우 POST 키를 생략한다. 원본 commit과 실제 `csrf_shape` 진단을 근거로 위의 제한된 호환 처리를 독립 구현했다. 참고 소스의 비밀번호 입력·로그 정책은 가져오지 않는다.

0.3.8의 합성 테스트 통과만으로 실제 누락 원인이나 native Canvas 로그인 해결을 주장하지 않는다. 다음 정상 인증의 학교 발급 폼, 인증 POST 결과, native Canvas 본인 신원과 소유 강좌 읽기를 각각 확인해야 한다. LearningX client 반환이나 `_normandy_session` 존재는 그 검증을 대신하지 않는다.

## 추가 구조 진단

`LmsCanvasFrameEvidence.canvasCsrfFieldState`는 선택 필드이며 `absent | present | empty | multiple | unknown`이다. 정확한 Canvas POST form이 하나인 경우에만 내부 필드 수와 비어 있는지를 분류한다. 그 외는 `unknown`이다. `present`는 값의 길이·암호화 자료·학교 인증 성공을 보증하지 않는다. 0.3.8에서는 frame 진단을 얻을 때 값을 항상 제공하지만, 이전 저장 데이터에는 없어도 된다.

기존 `canvasParseReason` enum은 바꾸지 않는다. 원문 HTML, URL/query, CSRF 값, 사용자 식별자, 암호문, 개인키, 복호화 결과, 내부 crypto 오류를 진단·공개 응답·분석 이벤트에 넣지 않는다. Backend가 선택 enum을 명시적으로 허용한 뒤 암호화 진단에 보존한다.

## 검사

합성 입력으로 정상 기존 CSRF form, 허용 경로의 필드 부재, 일반 페이지 누락, 빈 값·공백·중복·초과 길이, 사용자 불일치·중복, RSA 자료 누락·불량, 정확한 POST 키 생략, 불량 입력 시 요청 없음, LearningX 토큰 범위, 구조 진단의 비식별성을 확인한다. 실제 학교 학습·출석·제출 변경 테스트는 포함하지 않는다.
