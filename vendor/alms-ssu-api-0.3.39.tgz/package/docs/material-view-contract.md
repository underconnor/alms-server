# PDF 실제 열람 보고 · 0.3.10

## 학교 소스에서 확인한 규격

2026-10-02에 본인 소유 PDF의 상세를 읽어 원문 viewer → settings XML → `player_uri` → 실제 custom script를 따라갔다. 스크립트를 실행하거나 학교 상태를 변경하지 않고 공개 정적 소스와 XML을 읽었다. 학생 응답·viewer 원문·자료 본문·식별자는 저장소에 포함하지 않는다.

- [UniPlayer](https://commons.ssu.ac.kr/viewer/uniplayer/uni-player.min.js)의 `UniPlayerDoc.onDocPlayerInitialized`는 현재 쪽·전체 쪽·열람 쪽을 기록한 뒤 PLAYING 이벤트를 보낸다. 쪽 변경은 실제 현재 쪽을 기록하고 GO_TO_SLIDE 이벤트를 보낸다.
- [이벤트 연결](https://commons.ssu.ac.kr/viewer/ssplayer/uniplayer_support/uni-player-event.js)은 이를 `afterPlayStateChange`와 `afterGotoSlide`로 전달한다.
- [현재 학교 보고 스크립트](https://commons.ssu.ac.kr/viewer/uniplayer/custom/uniplayer_cscript.js)는 처음 열면 `state=3`, 쪽이 바뀌면 `state=8`을 보낸다. PDF 시간 값은 모두 0이며 `page`, `totalpage`, `cumulativePage`가 실제 쪽 기록이다. `cumulativePage`는 쪽별 열람 여부를 담은 0/1 문자열이다.
- 스크립트의 AJAX 설정은 POST+JSONP이나, 같은 UniPlayer에 포함된 jQuery 1.11.1의 cross-domain script prefilter가 GET으로 바꾼다. 실제 라이브러리 요청도 이 GET transport를 사용한다. **읽기용 GET이 아니라 학교 기록 변경 요청**이다.
- 원문 `TargetUrl`의 `user_id`는 현재 인증의 `bootstrap.userLogin`과 일치한다. Canvas 숫자 `userId`와는 다르다. course·component·content ID와 PDF 타입도 각각 대조했다. section은 학교가 발급한 숫자를 보존한다. 실제 상세의 `course_sctn_ids`는 빈 배열이므로 독립적인 section 연결을 검증했다고 확대하지 않는다. course/component/user/content 결합과 새 학교 발급 주소를 기준으로 한다.

검증한 정적 소스 SHA-256:

| 소스 | SHA-256 |
| --- | --- |
| UniPlayer | `33a299812f27eb18c866e33f124e4c7ad1f198eaf822f80e679fce71335acb68` |
| 이벤트 연결 | `8936babfae7146f1076be87f349bf0db9fce9c107db37efc1f7ac594440ca72b` |
| 보고 스크립트 | `7e6153460179083c25bc9263b76a69d1189b669e870bb5393d81cb4ee5a80a15` |

## 호출 계약

```ts
const pageCountCache = createSchoolMaterialPageCountCache(); // Backend process 범위
const result = await client.acknowledgeMaterialView(courseId, moduleItemId, {
  event: 'opened', // 같은 뷰어의 후속 쪽 변화는 page_changed
  page: 2,
  totalPages: 18,
  viewedPages: [2], // 실제 표시한 쪽만; 선행 렌더링/캐싱 제외
}, {
  beforeWrite: async () => { /* 현재 ALMS 로그인과 학교 인증 generation 재확인 */ },
  pageCountCache,
});
// result = {report:'recorded'|'already_completed', detail: freshSchoolDetail}
```

Backend가 강좌 소유권을 확인한다. 라이브러리는 모듈과 활동 상세를 새로 조회하고 PDF·공개·열림·`omit_progress=false`를 검증한다. 학교에 새 보고를 할 때는 원문 callback의 강좌·활동·사용자·자료 ID도 검증한다. 파일·영상·과제·퀴즈에는 이 보고를 적용하지 않는다.

자료 쪽수는 익명 viewer/content XML/slide XML의 3단계 경로로 확인한다. `sharedocs`, duration 0, 같은 콘텐츠 ID, 단일 PDF와 순서대로 이어지는 `seq/page/file_idref`만 지원한다. 실제 확인한 `contents31/ssu1000001/:contentId/contents/web_files/slide_list.xml` 경로 외에는 확장 근거가 필요하다. 쪽수와 열람 쪽은 1–10,000 범위이며 현재 쪽이 반드시 열람 쪽 집합에 포함돼야 한다. 중복·비정수·잘못된 이벤트는 요청 전에 거부한다.

선택적 캐시는 콘텐츠 ID와 학교 자료의 `updated_at`이 같은 익명 manifest 쪽수만 5분·최대128개 보관한다. 버전이 없거나 달라지면 새로 읽는다. 인증·소유권·공개 여부·학교 완료 결과·학생 callback은 캐시하지 않는다. 자료 내용 자체도 이 보고 메서드에서 다운로드하지 않는다.

검증을 마치면 필수 `beforeWrite`를 기다리고 고정 callback `almsMaterialView`로 한 번 보고한다. 리다이렉트는 전부 거부한다. 응답 JSONP는 정해진 wrapper에서 JSON만 파싱하며 JavaScript를 실행하지 않는다. `result === true` 응답 뒤 활동 상세를 다시 읽는다. `report:'recorded'`는 보고 수신을 뜻하며, 완료·출석 인정은 반환된 학교 상세의 nullable 필드를 그대로 사용한다. 학교 보고 뒤 결과 조회가 실패해도 완료로 대체하지 않는다. 강제 완료·중복 재생 취소·시간 증가·전체 쪽 자동 채우기를 하지 않는다.

## 0.3.10 이미 완료된 PDF

새 모듈과 활동 상세의 강좌·활동 연결, PDF·공개·열림·`omit_progress=false`, 자료 식별자와 기본 viewer 형식을 확인한 뒤 학교의 `attendance.completed === true`이면 `{report:'already_completed', detail}`을 반환한다. 이때는 manifest 조회, `beforeWrite`, 학교 보고를 하지 않는다. 완료 여부는 캐시하지 않으며 다음 호출에서도 새 학교 상세를 확인한다. Backend는 이 응답도 반환 직전 현재 사용자·학교 인증 generation을 다시 검증해야 한다.

완료 값이 false·null·누락·잘못된 타입이면 기존 callback 결합 검사와 쪽수 검증, `beforeWrite`, 단일 보고, 후속 조회를 그대로 수행한다. 기한 경과만으로 완료를 추정하거나 학교가 생략한 `TargetUrl`을 만들지 않는다. `already_completed`는 이미 받은 학교 완료 상태의 재확인이며 새 열람 보고·새 출석 인정의 증거가 아니다.

2026-10-02 본인 소유 PDF 하나에서 완료 true·기한 경과 true와 `TargetUrl` 부재를 함께 관찰했다. 학교 공개 보고 스크립트도 보고 주소가 비어 있으면 전송하지 않는다. 이 관찰만으로 주소 생략의 원인이 기한 또는 완료 상태라고 일반화하지 않는다. 구현 검사는 합성 응답으로 진행했고 실제 학교 보고를 하지 않았다.

## 실제 검증 경계

본인 PDF의 읽기·원문 ID 결합·18쪽 manifest와 공개 스크립트 규격은 확인했다. 라이브러리 자체 테스트는 합성 응답을 사용한다. 이 패키지 구현 중 실제 학교 기록 변경은 수행하지 않았다. 운영의 실제 화면 열람 → 학교 보고 → 새 학교 상태 확인은 통합 담당자가 별도로 기록한다.

## 0.3.9 실패 단계 진단

`acknowledgeMaterialView()` 안의 알려진 `SchoolError`는 `SchoolMaterialViewError`로 전달한다. 기존 `code`와 `retryable`은 유지하고 다음 세 가지 `stage` 중 하나만 추가한다.

| stage | 실패한 범위 |
| --- | --- |
| `validation` | 입력 검사, 새 모듈·활동 상세 조회와 검증, 익명 쪽수 manifest 조회와 검증 |
| `callback` | 학교 보고 요청, 응답 형식 검사, 고정 JSONP acknowledgement 파싱 |
| `refresh` | 보고 acknowledgement 이후 새 활동 상세 조회와 파싱 |

`beforeWrite`는 이 진단 처리 밖에서 실행한다. 호출자의 인증 만료·취소 등 모든 예외는 같은 객체로 전달하며 학교 오류로 바꾸지 않는다. 그 밖의 알 수 없는 예외에도 학교 단계를 추정해 붙이지 않는다. 새 오류에는 고정 `name`, `code`, `retryable`, `stage`만 보존하며 원래 메시지·응답·URL·식별자·`cause`를 복사하지 않는다. Backend는 필요한 고정 값만 골라 기록해야 한다.

요청 순서·학교 보고 횟수·재시도·성공 결과는 바꾸지 않는다. 특히 `callback` 실패는 학교에 기록이 없다는 뜻이 아니므로 자동 재시도의 근거로 쓰지 않는다. `refresh` 실패도 완료·출석 인정으로 대체하지 않는다. 이 변경은 합성 회귀 검사로 검증하며, 특정 운영 오류의 실제 원인은 다음 정상 사용에서 별도로 확인한다.
