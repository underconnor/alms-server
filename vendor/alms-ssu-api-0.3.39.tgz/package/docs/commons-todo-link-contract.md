# Commons TODO 연결 메타정보

## 0.3.39 · Readystream 상세와 재생 권한 분리

정확한 Readystream 관계는 기존 TODO marker와 함께 `activityDetailAvailable:true`로 본문 메타정보를 읽는다. 다른 Commons 유형을 포함한 attendance ID 중복을 거절하고 원래 `resourceType:readystream`을 유지한다. 상세/시간값은 단일 UPF 검증이나 보고 권한이 아니다. Backend는 새 mapping proof에서 목록·본문의 유형을 일치시키고, 같은 사용자·학교 generation·정확한 course/module/attendance/content 관계와 단일 미디어 형식을 검증한 뒤만 수동 capability를 제공한다. 서버 자동수강은 이 변경으로 활성화하지 않는다. [Readystream 계약](readystream-video-contract.md)

아래는 각 버전 당시의 범위다.

SDK 0.3.29. 학교 Dashboard 공개 JS `4.82.9`의 `use_purecanvas` 분기와 기존 검증된 모듈 관계를 보존한다. 이 계약은 읽기 파서이며 TODO 이동이나 학교 학습 기록을 생성하지 않는다.

## 강좌와 모듈

- `SchoolCourse.usePureCanvas`는 학교 `use_purecanvas`가 boolean일 때만 같은 값이다. 누락·null·문자열·숫자는 null이다. `course_type`에서 추론하지 않는다.
- 지원 Commons 모듈은 `attendanceItemId?: string`에 `content_data.item_id`를 보존한다. 이 값은 `item.id`인 `module_item_id`와 다르다.
- 기존 `resolveModuleActivity`로 정확한 `attendance_item` → `commons` → 지원 유형(`movie`·`mp4`·`pdf`·`file`)과 같은 강좌의 관계를 검증한다. 모듈 ID 중복·다른 강좌·잘못된 ID는 거부한다. 누락·지원 밖 유형에는 필드를 추가하지 않는다.
- `mp4`의 공개 `resourceType`은 기존대로 `movie`다. 학교의 `published`·`completed`는 유지한다. 식별자 확인이나 열람 응답으로 완료·진도·출석을 합성하지 않는다.
- 모듈 ID로 원본 항목을 한 번 색인한 뒤 기존 resolver를 실행한다. 각 Commons 항목마다 전체 강좌 목록을 다시 순회하지 않는다.

## 소비자가 확인할 조건

Backend는 같은 사용자·학교 인증 generation·강좌의 검증된 자료에서만 TODO를 연결한다. `usePureCanvas === true`, TODO `componentId`와 `attendanceItemId`의 정확한 일치, 지원 Commons 유형 일치, 단일 항목과 `published !== false`를 모두 확인해야 한다. 같은 attendance ID를 가진 복수 모듈은 파서에서 보존하므로 Backend가 유일성을 검사해야 한다.

레거시 false·unknown null·구 캐시·누락·중복·다른 유형은 Commons item-ID 경로로 연결하지 않는다. 제목이나 task 해시·모듈 ID의 우연한 숫자 일치를 사용하지 않는다. SDK는 추가 모듈 HTTP 조회·TODO 캐시·개인 완료 저장·ALMS 세션 정책을 수행하지 않는다.

## 0.3.38 · readystream의 읽기 전용 TODO 참조

`attendance_item` → `commons` → 정확한 `readystream`은 본문·미디어 지원과 별도로 관계 정보만 보존한다. `content_data.course_id`가 요청 강좌와 같고 명시적인 `content_data.item_id`가 유효할 때 `todoReferenceAvailable: true`와 `attendanceItemId`를 제공한다. 두 ID의 누락·null에는 두 필드를 추가하지 않으며, 제공한 ID가 잘못됐거나 다른 강좌이면 거절한다.

모듈 ID·module item ID·readystream 참조 ID가 응답 안에서 중복되면 거절한다. 기존 지원 유형의 공유 attendance ID 보존 규칙은 유지하므로 소비자는 여러 유형을 포함한 모든 후보의 ID 유일성을 확인해야 한다. 제목이나 생성한 Canvas module URL만으로 TODO와 모듈의 관계를 만들지 않는다.

새 참조에는 `activityDetailAvailable`을 추가하지 않는다. `resolveModuleActivity`와 `parseActivityDetail`은 `readystream`을 계속 미지원으로 거절한다. 따라서 이 marker나 `attendanceItemId`를 상세·재생·진도/출석 전송 권한으로 사용하면 안 된다. movie/mp4/pdf/file의 기존 상세 지원은 유지한다. HTTP host·Origin·API·인증 전달 범위와 학교 요청 수는 변경하지 않는다.

Backend는 `todoReferenceAvailable === true`, 정확한 Commons/readystream 유형, TODO `componentId === attendanceItemId`, `usePureCanvas === true`, `published !== false`, 같은 사용자·현재 학교 인증 generation·강좌의 단일 관계를 확인한 뒤 링크만 추가한다. 구 캐시에는 이 marker가 없으므로 readystream 관계로 재사용하지 않는다. 공개 학습 유형은 `other`이며 상세·재생 미지원 상태를 유지한다. 캐시 proof 버전과 최종 세션 검증은 Backend 책임이다.

## 검증 범위

합성 파서 검사로 boolean/unknown, 지원 유형, 누락·잘못된 ID, 모듈 ID 중복·다른 강좌·지원 밖 유형·공개 여부·복수 attendance ID 보존을 확인한다. 실제 학교 TODO → 주차 본문 이동과 서버 상태 저장은 별도 통합 QA다. 학교 쓰기는 이 변경에 포함되지 않는다.
