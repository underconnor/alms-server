## 0.3.27 읽기 범위와 제출 권한 분리

목록·상세는 매번 native 본인 id/login과 fresh LearningX 전체 학기·수강 목록을 확인한다. 안내/최근 본인 제출 파일과 본인 제출 이력·시도별 파일도 같은 전체 학기 읽기 권한을 사용한다. `default`가 false/null이거나 강좌가 `ended:true/null`이어도 실제 검증한 학기의 수강 목록에 지정 강좌가 있어야 한다. 빈 학기·미등록 강좌는 forbidden_target, 중복 학기/강좌 ID나 반환 학기 밖 강좌는 unexpected_response다. 학교의 기본 학기나 연도·제목으로 과거 강좌를 추측하지 않는다.

기존 `ownedAssignmentRead`의 default 학기 선택과 제출 조건·최종 제출·reconcile 경로는 유지한다. default는 학교 dashboard의 초기 선택이며 활성 수강을 보장하지 않는다. 제출은 기존 학교 폼·잠금·개인 과제·시도 횟수를 재검증한다. 읽기를 위한 새 helper는 이 권한을 부여하지 않는다.

전체 60초·최대30GET·30학기·100강좌·JSON 2MiB/응답·8MiB 합계 상한은 그대로다. 전체 수강 강좌가 100개를 넘으면 unsupported로 끝내며 현재/과거 일부만 골라 성공하지 않는다. 읽기 signature와 DTO는 유지한다. 과거 학기의 실제 지원과 학교 권한 응답은 합성 검사 결과와 별도로 확인한다.

## 0.3.25 상세·첨부 확장

과제 목록은 제출 본문/URL을 포함하지 않는다. 상세만 `descriptionAttachments: SchoolAssignmentAttachment[]`와 `ownSubmittedContent: {text:string|null,url:string|null}|null`을 포함한다. 본인 신원과 강좌·과제·제출 식별자를 검증한 뒤 submitted/graded/pending_review의 현재 제출만 표시한다. HTML은 기존 텍스트 파서로 정리하며 웹 주소는 자격정보 없는 HTTP(S)만 허용한다. 로그·사용 분석에는 넣지 않는다.

상세 첨부의 `downloadAvailable=true`는 현재 설명의 같은 강좌 다운로드 링크 또는 현재 본인 제출에 실제 발급된 파일 ID·URL·쿼리를 검증한 경우만이다. 원본·서명 URL은 DTO에 포함하지 않는다. 목록과 제출 영수증의 첨부 flag는 false를 유지한다. 설명 링크가 없으면 배열은 []다. 별도 `assignmentAttachment`가 매번 신원·수강권한·파일 연결을 새로 검증한다.

주차 모듈은 content_type=assignment인 경우 학교의 `content_id`를 `assignmentId`로 보존한다. 2026-10-07 학교 GET 9회에서 동일 강좌의 네 항목 모두 native 과제 목록 ID와 정확히 일치하며 각 모듈이 유일한 것을 확인했다. 제목으로 연결하지 않는다. native 상세의 moduleItemId는 계속 null이므로 소비자는 받은 주차의 exact assignmentId로 연결한다. [Canvas ModuleItem](https://developerdocs.instructure.com/services/canvas/resources/modules)의 content_id 계약을 참고했다.

아래는 최초 구현 당시 계약이며 위 상세 확장이 우선한다.

# 본인 강좌의 과제·제출 결과 읽기

`LearningxClient.assignments(courseId, signal?)`는 검증한 전체 학기 소유 강좌의 전체 과제 목록을 반환한다. `assignmentDetail(courseId, assignmentId, signal?)`는 과제 상세와 본인의 최신 제출 결과를 따로 읽는다. 두 메서드 모두 매번 native Canvas 본인 신원과 fresh LearningX 수강 목록을 먼저 대조한다. 학번·비밀번호 입력, 제출·응시·읽음 표시·학교 진도 쓰기·파일 다운로드를 수행하지 않는다.

## 실제 확인과 공식 계약

통합 담당자는 2026-10-02 운영 SDK 0.3.14의 native 신원·현재 강좌 확인 후 과제 하나의 목록·상세·본인 제출 GET을 실측했다. bootstrap와 캘린더를 포함한 12개 GET이 모두 200이며, 과제/강좌/본인 식별자가 일치했다. 목록은 1개·다음 페이지 없음, 제출 상태는 submitted, 첨부 1개·피드백 0개, grade/score 누락·graded_at/posted_at null이었다. 저장 세션과 학교 기록 쓰기는 없었다. 실제 원문은 이 저장소에 보관하지 않는다.

[Canvas Assignments](https://developerdocs.instructure.com/services/canvas/resources/assignments), [Submissions](https://developerdocs.instructure.com/services/canvas/resources/submissions), [Files](https://developerdocs.instructure.com/services/canvas/resources/files)의 공식 계약을 참고했다. 다른 제출 상태·공개 점수·이전 평가·피드백·파일 메타 형태·페이지 2 이상·1,000개 상한은 합성 검사이며 학교 실측으로 확대하지 않는다. 현재 학교 버전에서 확인하지 못한 rubric·첨부 다운로드·제출/재제출은 남은 기능이다.

## 요청과 신원

1. `/api/v1/users/self/profile`의 id/login_id가 bootstrap userId/userLogin과 각각 일치해야 한다.
2. LearningX 전체 terms·courses를 새로 읽는다. 입력 강좌가 검증한 전체 학기의 수강 목록에 있어야 한다. 제출 조건·쓰기·reconcile은 별도 기존 default 학기 선택을 유지한다.
3. 목록은 `GET /api/v1/courses/:course/assignments?include[]=submission&per_page=50`이다. 실제 Link rel=next의 page token만 따라가며 origin·path·query scope가 바뀌면 실패한다.
4. 상세는 `GET /api/v1/courses/:course/assignments/:assignment?include[]=submission`을 읽고 응답의 course_id/id와 embedded submission의 assignment_id/user_id를 검증한다.
5. 그 후 `GET /api/v1/courses/:course/assignments/:assignment/submissions/:verifiedNativeUserId?include[]=submission_comments&include[]=rubric_assessment`로 본인 제출을 다시 읽는다. assignment_id/user_id가 다르거나 assignment_visible가 명시적으로 false이면 거부한다. rubric은 이번 DTO에 포함하지 않는다.

native에는 Canvas jar 쿠키만 사용하며 xn_api_token·sToken·sIdno·Authorization을 보내지 않는다. LearningX Bearer는 기존 `/learningx/`에서만 사용한다. 새 목적별 URL 검사는 calendar/generic 허용 범위를 확장하지 않는다. 모든 요청은 GET, redirects는 거부하며 `read_status`, observed_users, 전체 학생 제출 목록, 임의 include/query는 허용하지 않는다. 공식 read_status include는 읽음 상태를 바꿀 수 있으므로 읽기 계약에서 제외한다.

## DTO와 상태 의미

- 목록은 `{courseId,items,complete:true}`다. 범위·페이지·응답 오류가 있으면 부분 목록이나 빈 성공을 반환하지 않는다.
- 항목은 id/courseId/title, 기간, published/lockedForUser, submissionTypes, allowedExtensions, pointsPossible, allowedAttempts와 nullable sourceUrl을 가진다. 학교 값이 없으면 boolean/수치/기간을 null로 유지한다. `allowedAttempts=-1`은 공식 계약의 제한 없음을 보존한다. 알려지지 않은 제출 방식은 `unknown`이다.
- `moduleItemId`는 항상 null이다. assignment ID를 모듈 ID로 사용하지 않으며, 이름으로 연결하거나 native/LearningX ID가 같다고 가정하지 않는다.
- `submissionState`는 missing/null/available이며 `submission`은 null 또는 본인 결과다. TODO에서 빠졌다는 이유로 submitted를 만들지 않는다. 알려진 workflowState는 unsubmitted/submitted/graded/pending_review이며 그 외는 unknown이다.
- 제출 결과의 attempt·시각·late/missing/excused·gradeMatchesCurrentSubmission은 nullable다. postedAt은 학교 필드가 없으면 생략하고 명시된 null은 null로 유지한다. 학교의 submitted와 graded를 같은 상태로 합치지 않는다.
- 상세의 descriptionText/lockExplanationText는 script·활성 요소를 제거하고 줄바꿈을 보존한 텍스트다. 본문 입력은 200,000자 이하이며 실행·외부 리소스 요청은 없다. 제출물 body/url·교수/학생 신원·preview URL은 반환하지 않는다.
- 첨부는 `{id,fileName,contentType,sizeBytes,downloadAvailable:false}`다. 0.3.21의 별도 `assignmentAttachment` 메서드는 본인·수강권한·과제/파일을 새로 확인해 바이트를 읽지만 기존 Backend의 읽기 계약을 보존하기 위해 이 flag는 유지한다. UI 다운로드 활성화는 Backend/Front 계약을 함께 변경한 뒤 수행한다. fileName은 display_name 또는 filename 중 학교 값을 사용하고, signed URL은 버린다. attachments=null은 미제공, []는 실제 빈 배열이다. 피드백도 null과 []를 구분하며 `{id,text,createdAt}`만 반환한다. 작성자와 미디어 URL은 제외한다.
- sourceUrl은 정확한 query 없는 `https://canvas.ssu.ac.kr/courses/:course/assignments/:assignment`만 유지한다. 그 외는 null이다.

### 현재 공개 점수의 최소 조건

성적 값은 서버에서 먼저 제한한다. `resultVisibility` 판정 우선순위는 다음과 같다.

1. gradeMatchesCurrentSubmission=false → stale. postedAt 누락/null보다 우선한다.
2. postedAt이 명시적 null → not_posted.
3. postedAt 누락 또는 gradeMatchesCurrentSubmission 미확인 → unknown.
4. 유효한 postedAt과 gradeMatchesCurrentSubmission=true → available.

scoreState/gradeState는 각각 missing/null/available/withheld다. 원래 누락 필드는 DTO에서도 생략하고 state=missing, 원래 null은 null과 state=null이다. 실제 값이 있어도 위 available 조건이 아니면 null과 state=withheld로 바꾼다. available일 때만 검증한 점수/등급을 반환한다. 실제 점수 0은 보존하며, 누락/미공개/이전 점수를 0 또는 현재 평가로 대체하지 않는다. resultVisibility=available도 해당 필드의 값 존재를 보장하지 않으므로 Front는 개별 state까지 확인해야 한다. 학사 최종 성적을 의미하지 않는다.

## 상한과 오류

전체 60초, 요청 15초 또는 더 엄격한 HTTP 설정, 응답 2MiB·합계 8MiB, GET 30회, 학기 30개·강좌 100개, 50개/page·20page·1,000개 과제를 제한한다. 첨부/피드백은 각각 100개까지다. 동일 ID의 일치하는 중복은 제거하지만 서로 다른 내용이면 실패한다. native 401/403은 authentication_required, 신원 불일치는 identity_mismatch, 다른 강좌/본인 식별자·목적지 이탈은 forbidden_target, 구조/순환 Link는 unexpected_response, 상한은 unsupported, 취소/시간 초과는 retryable upstream_unavailable이다.

취소는 소유권 확인을 포함한 모든 단계에 적용하며 이후 요청을 시작하지 않는다. transport가 signal을 무시해도 제한 시간 뒤 중단하고 늦은 body를 정리한다. 원본 응답·URL·cause는 오류에 복사하지 않는다. 같은 사용자의 jar 갱신만 수행하며 저장 generation/CAS·암호화 캐시·응답 직전 사용자 검증은 Backend 책임이다. 자동 재시도와 학교 기록 변경은 없다.
