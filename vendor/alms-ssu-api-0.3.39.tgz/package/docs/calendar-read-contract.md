# 소유 강좌의 학교 캘린더 읽기

`LearningxClient.calendar({start, end, courseId?}, signal?)`는 같은 사용자의 native Canvas 신원과 현재 학기 소유 강좌를 다시 검증하고 일정·과제 기한을 읽는다. `start`, `end`는 유효한 `YYYY-MM-DD`이며 Asia/Seoul 자정 기준 1~31일의 `[start, end)` 구간이다. 개인 일정·일정 쓰기·제출·출석·예약은 포함하지 않는다.

## 근거와 신원 경계

2026-10-02 통합 담당자의 새 로그인 QA에서 native 본인 profile, 소유 강좌, visible contexts, 한 달 일정 1개·과제 기한 1개를 HTTP 200으로 확인했다. 추가 읽기에서는 각각 `type=event`/`assignment`, `assignment_<숫자>` 식별자, 과제 start/end와 nested due_at의 동일한 시각을 확인했다. 실제 강좌/계정 응답은 이 저장소에 보관하지 않는다. 다른 계정·학기·종일 다일 구간과 페이지 2 이후는 합성 계약 검증이며 학교 실측 완료로 확대하지 않는다.

학교에서 관찰한 경로와 [Canvas Calendar Events 문서](https://developerdocs.instructure.com/services/canvas/resources/calendar_events), [페이지네이션 문서](https://developerdocs.instructure.com/services/canvas/basics/file.pagination)를 기준으로 한다. 공식 query의 end_date는 포함 경계이므로, ALMS의 끝 제외 구간은 응답을 받은 뒤 따로 적용한다. context는 요청당 10개 이하로 나눈다. 다음 페이지는 실제 Link의 rel=next로만 이동한다.

1. `/api/v1/users/self/profile`의 id와 login_id를 검증된 LearningX bootstrap의 userId/userLogin에 각각 대조한다.
2. 기존 LearningX terms를 새로 읽어 학교 default term을 선택한다. default가 없다면 기존 대시보드 규칙처럼 첫 학기를 선택한다. 해당 term의 courses를 새로 읽고 응답 term/강좌 중복을 확인한다.
3. 선택한 강좌가 현재 소유 목록에 있음을 확인한다. 전체 선택이면 모든 현재 강좌를 10개씩 나눠 event와 assignment를 각각 읽는다. visible_contexts는 사용자가 선택한 UI 상태이며 소유권 근거로 쓰지 않는다.

native에는 Canvas 목적지에 맞는 jar 쿠키만 전달한다. LearningX Bearer와 xn_api_token은 `/learningx/` 경로에서만 사용한다. sToken/sIdno는 두 경로 모두 제외한다. 정상 응답의 쿠키 갱신은 같은 사용자의 jar에만 적용하며, 저장 여부와 인증 generation/CAS는 Backend가 책임진다. 기존 generic HTTP 범위와 인증 흐름은 변경하지 않는다.

## 응답

성공은 `{start,end,timeZone:'Asia/Seoul',courses,items,complete:true}`다. `courses`는 필터와 무관한 전체 현재 학기 목록 `{id,title}`이며, `items`만 선택 강좌로 제한한다. 부분 결과를 정상 빈 일정이나 완료로 반환하지 않는다.

각 item은 id, type, courseId, title, startsAt, endsAt, allDay, allDayDate, dueAt, assignmentId, descriptionText, location, sourceUrl을 가진다. 시각은 timezone을 명시한 학교 값을 UTC ISO로 정규화한다. 종일 날짜는 학교 all_day_date를 그대로 유지한다. description은 활성 요소를 제거한 텍스트이며 Front에 원문 HTML을 넘기지 않는다. 학번·이메일·profile·context·원본 응답·보고서 정보는 DTO에서 제외한다. 제품 분석/운영 로그에는 제목·설명·위치·강좌/일정 ID를 넣지 않는다.

- 일반 시간 일정은 `[startsAt, endsAt)`와 조회 구간이 겹칠 때 표시한다. 끝이 없거나 같은 시각이면 시작 시각의 한 점으로 취급한다. startsAt 누락·잘못된 날짜·역전된 구간은 오류다.
- 종일 항목은 학교 allDayDate의 하루에 표시한다. startsAt/endsAt도 있으면 보존하지만, 아직 검증하지 않은 다일 종일 끝 날짜를 임의로 확장하지 않는다. 날짜가 없으면 오류다.
- 과제는 `assignment_<id>`, nested id/course_id, start/end와 due_at의 동일한 시각을 확인한다. dueAt을 별도로 보존하며 종일 과제의 실제 마감 시각을 지우지 않는다. 기한을 제출·완료·출석 증거로 사용하지 않는다.
- 명시된 deleted 일정과 unpublished 과제는 제외한다. hidden parent는 제한 깊이에서 소유 context를 다시 검증한 child_events를 읽는다.
- course context 또는 명시된 effective_context_code가 같은 소유 강좌인 course_section만 허용한다. 개인·그룹·다른 강좌·여러 effective context·모순된 context는 오류다.
- sourceUrl은 학교가 반환한 정확한 `https://canvas.ssu.ac.kr/courses/{courseId}/assignments/{assignmentId}`만 유지한다. query/fragment/userinfo/다른 ID가 있으면 null이다. query 기반 calendar 원문 링크는 null이며 보조 원문 이동은 제품의 검증된 대체 경로를 사용한다. assignmentId와 학습 module ID를 추측해 연결하지 않는다.

## 제한과 실패

목적별 GET은 정확한 Canvas 경로·query만 허용하며 redirect는 거부한다. Link도 origin/path/type/start/end/context/per_page를 원래 요청과 대조한다. page 값은 길이 제한을 둔 opaque token으로 취급하며, 임의 다음 페이지 번호를 생성하지 않는다. 중복 Link/순환·상충하는 중복 일정은 오류다.

| 항목 | 상한 |
| --- | --- |
| 전체 SDK 작업 / 요청 | 60초 / 15초 또는 더 작은 HTTP 설정 |
| 응답 하나 / 합계 | 2MiB / 8MiB |
| 학교 GET | 100회 |
| 학기 / 현재 강좌 | 30개 / 100개 |
| 한 요청 context / per_page | 10개 / 50개 |
| 각 context 묶음·종류의 페이지 | 10개 |
| 최종 일정 | 2,000개 |
| child tree | 페이지당 2,000개 방문·깊이 2 |

취소는 다음 요청을 막고 진행 중 fetch/body read를 중단한다. signal을 무시하는 transport도 제한 시간 뒤 반환되며 늦은 body를 정리한다. 쿠키 저장/transport의 원래 예외나 URL은 SchoolError에 복사하지 않는다. 인증 401/403은 authentication_required, 신원 불일치는 identity_mismatch, 소유권·목적지 이탈은 forbidden_target, 구조·Link 순환은 unexpected_response, 조회 상한은 unsupported, 취소·시간 초과는 재시도 가능한 upstream_unavailable이다. 자동 재시도는 없다.

합성 검사는 정상 흐름 외에 다른 계정/강좌, 10개 초과 배치, 기간 경계·종일/시차, 과제 ID, hidden/section, 실제 Link 검증·순환·상한, 응답 형식/크기, 취소·지연 transport와 비밀 값 비노출을 확인한다. 라이브러리 검사·Backend/Front 통합·운영 배포·학교 UI QA는 별도 완료 조건이다.

## 본인 제출 여부 (0.3.20)

`userSubmitted: boolean | null`은 인증된 본인의 Canvas `assignment.user_submitted`만 전달한다. `true`는 제출 완료, `false`는 제출 내역 없음, 누락·null은 확인되지 않음이다. 모든 학생의 제출 여부인 `has_submitted_submissions`, 날짜 경과, 개인 TODO 체크를 이 값의 근거로 사용하지 않는다. 일반 일정은 항상 null이다. 이 값은 채점·면제·출석·퀴즈 성공 결과를 뜻하지 않는다. 기존 native 본인 신원과 최신 수강권한 검증 뒤 같은 캘린더 응답에서 읽으며 추가 요청이나 학교 쓰기를 하지 않는다.
