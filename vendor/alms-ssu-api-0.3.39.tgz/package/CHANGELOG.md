# 변경 이력

## 0.3.39

- 정확한 Commons `readystream`의 상세·fresh 학습 상태를 초 단위로 읽고 원래 resource/callback 유형을 보존한다. 모듈/상세의 정확한 유형·content ID와 단일 활동 관계를 대조하며 TODO marker는 기존대로 보존한다.
- 검증한 contents31/ssu-toast 단일 video1 UPF만 해석한다. 해당 분기에서만 관찰한 ASCII 괄호 파일명을 허용하며 기존 movie·일반 HTTP host 범위를 유지한다.
- media 검증을 마친 특정 opaque launch에만 private 검증을 부여한다. callback·보고 request/controller·명시적 start는 이를 요구하고 기존 endat/baseline·page0·소유/세대·관측 시간/진도 상한·재전송 금지 계약을 유지한다.
- 조회/manifest/공개 정적 소스 근거와 합성 회귀에 기반한 후보다. SDK .39의 실제 재생·학교 ACK·완료·출석·새 로그인과 배포는 통합 담당자의 별도 QA다. [Readystream 계약](docs/readystream-video-contract.md)

## 0.3.38

- `attendance_item` → `commons` → `readystream`에 한해 같은 강좌의 명시적인 `content_data.item_id`를 `attendanceItemId`와 `todoReferenceAvailable: true`로 보존한다. 모듈·항목·readystream 참조 ID 중복, 다른 강좌, 잘못된 식별자는 거절한다. 제목으로 연결하거나 모듈 ID를 참조 ID로 대체하지 않는다.
- 새 필드는 읽기 전용 TODO 관계 정보다. `readystream`의 상세·재생·학교 진도/출석 전송은 계속 미지원이며 기존 movie/mp4/pdf/file의 상세 지원과 요청·인증 범위는 유지한다. Backend는 현재 사용자·학교 인증 세대·강좌와 정확한 유형·ID·단일 관계를 추가 검증해야 한다.
- 합성 파서·지원 경계 회귀를 추가한다. 실제 학교 재생·학습 기록·제출을 수행하거나 성공으로 판정한 변경은 아니다.

## 0.3.37

- 수동 영상 관측에 선택적 `capturedAtMs`와 `client_monotonic_v1` capability를 추가한다. 첫 관측에서 선택한 모드를 고정하며, native player와 기존 타이밍 없는 adapter의 서버 시간 검사는 유지한다.
- 정상 5초 관측이 HTTP 도착 지연 차이로 압축될 때 발생하는 거절을 합성으로 재현했다. 클라이언트 관측 간격과 고정 5초 오차 한도를 사용하되 최초 전송 불확실성을 한 번만 제한하고, 서버 전체 경과시간·클라이언트 활성시간·구간/전체 clock drift를 각각 검사한다. 시간·진도 가산, 학교 payload 변경, 재전송은 추가하지 않는다.
- 관측 오류를 SDK 내부 WeakMap의 고정 `kind`로 구분하는 `inspectSchoolVideoObservationFailure`를 제공한다. 관측값·clock·URL·학교 식별자·원래 오류는 보관하지 않는다. 진단은 새 오류에만 적용하며 이전 운영 실패를 소급 분류하지 않는다.
- 클라이언트 신호는 출석 증명이 아니다. 지연 허용 범위 안에서 함께 위조한 위치·시간을 실제 네트워크 지연과 구분할 수 없으며, SDK 합성 통과는 실제 재생 종료·학교 진도·출석 인정 또는 운영 배포 성공을 뜻하지 않는다.

[수동 관측 타이밍 계약과 한계](docs/video-progress-contract.md#0337--수동-관측의-선택적-monotonic-타이밍)

## 0.3.36

- 검증한 같은 Canvas의 발급 `create_success` 완료 GET에서만, 구형 Canvas가 `text/html`로 내보내는 JSON 본문을 엄격한 UTF-8/JSON/객체 파서로 읽는다. 파일 ID를 완료 경로와 일치시키고 기존 이름·크기를 검증한다. 실제 HTML·스크립트·XSSI 접두사와 다른 단계의 HTML은 거절한다.
- 업로드 오류에 개인정보 없는 고정 `uploadStep`과 최종 제출 전송 경계 `finalSubmissionMayHaveWritten`을 추가한다. 파일 준비와 최종 제출의 결과를 구분하며 자동 재전송·이력 변경은 추가하지 않는다. 공식 소스의 호환성 결함과 합성 회귀를 확인했으며 과거 운영 실패의 원인이나 실제 학교 제출 성공을 확정하지 않는다.

- 제출 업로드와 같은 응답의 복제 첨부 확인에서 NFC/NFD로만 다른 파일명을 같은 이름으로 비교한다. 선택한 파일명·요청·바이트는 그대로 전달하고, 다른 이름·대소문자·호환 문자·크기·fresh 첨부 ID는 기존대로 검증한다.
- 합성 한글 파일명의 업로드가 `upload/unknown/unexpected_response`로 실패하던 경우를 재현했다. 실제 학교 응답의 정규화나 특정 운영 실패의 원인을 확인한 근거는 아니다. 미확정 제출의 재전송·이력 변경은 추가하지 않는다.

## 0.3.35

- 정확한 과제·본인 제출·과거 시도의 파일 연결을 검증한 다운로드에서 `Content-Disposition`의 원본 파일명을 읽는다. UTF-8 `filename*`를 우선하고 일반 `filename`을 지원하며, 없거나 모호한 헤더는 기존 안내 링크·본인 첨부 메타정보를 유지한다.
- 공개 첨부 결과의 기존 `fileName` 필드에 정규화한 이름만 반환한다. 위험 문자의 다운로드 경계 처리·240자 한도와 Unicode 경계를 검사하며 원문 헤더·URL·인증값은 추가하지 않는다. 학교 요청 수·대상·redirect·크기/시간 제한·업로드·최종 제출은 바꾸지 않는다.
- 안내 링크가 `강의자료`이고 파일 응답에 원래 이름이 있어도 사라지던 경우를 합성으로 재현했다. 현재 학교의 해당 파일명이나 학교 업로드·최종 제출 성공을 확인한 근거가 아니다.

[첨부 원본 파일명](docs/assignment-submit-contract.md#0335--첨부-원본-파일명)

## 0.3.34

- 공식 Canvas 로컬 업로드 수신 경로 `/files_api`와 학교가 발급한 `on_duplicate=rename`·10자리 소문자 hex `quota_exemption`을 지원한다. 두 값은 디코딩·재작성 없이 검증하며 완료 GET에서도 원래 발급값과 같아야 한다. 기존 `/files`·`/files/pending`의 쿼리 없는 계약은 유지한다.
- 같은 Canvas 호스트, 파일 마지막 전송, 본인·수강·과제·동의 재검증과 최종 receipt 저장 순서를 유지한다. 알 수 없는 쿼리·중복·변경된 완료값·외부 호스트는 차단하고 재시도·자동 제출·기한 변경은 추가하지 않는다.
- 고정한 공식 소스 계약으로 재현한 결함이며 과거 실제 제출 실패 원인을 복원하거나 학교 업로드 성공을 확인한 것은 아니다.

[업로드 수신 경로와 근거](docs/assignment-submit-contract.md#0334--공식-로컬-수신-경로와-발급-쿼리)

## 0.3.33

- 신원 파싱 실패의 `portalNavigation`에 스크립트 위치와 기존 Saint 경로·폼·메타 이동의 고정 분류 네 개를 추가한다. URL·쿼리·토큰·본문·해시는 보관하지 않고 스크립트를 실행하거나 목적지를 따라가지 않는다.
- 위치 분류는 정적 문법의 경계이며 함수 실행·실제 이동·인증 실패 원인을 뜻하지 않는다. 신원 검증·오류·쿠키·학교 요청 수와 재시도 금지는 유지한다. 이전 실패의 원인은 복원할 수 없으며 새 실제 콜백 검증이 필요하다.

[신원 확인 진단 계약](docs/sso-verification-diagnostics.md)

## 0.3.32

- 명시적 사용자 확인 뒤 보내는 별도 학교 시작의 ACK를 일반 진도 보고 ACK와 분리한다. 정확한 JSONP·객체·boolean `result`·own `error_code` 검증은 유지하고, 시작은 `result:true`를 승인한다. 시작의 `error_code` 값은 성공 조건에 사용하거나 저장하지 않는다.
- 일반 playing/update/ended 보고는 기존 `result:true,error_code:null` 조건을 유지한다. 시작의 false 응답과 `invalidpbrate` 분류·권한 재검증·일회 전송·fresh 학교 결과·자동 재시도 금지 조건도 유지한다.
- 기존 SHA와 일치하는 원본 정적 handler의 guard, 운영 시작의 `ack_error_code` 진단, fail-before/pass-after 합성 회귀를 구분해 기록한다. 시작 ACK는 학습 완료·출석 인정이나 과거 실패 복원을 뜻하지 않으며 후보의 실제 학교 성공은 아직 검증 전이다.

[시작 ACK의 근거와 범위](docs/video-playback-start-contract.md#0332--명시적-시작-ack-분리)

## 0.3.31

- 일반 보고와 분리된 `createSchoolVideoPlaybackStartController`·`startSchoolVideoPlayback`·`SchoolHttpClient.startVideoPlayback`을 추가한다. 명시적인 사용자 확인과 일시정지된 native 관측, 학교 발급 baseline/target, fresh 권한을 확인한 뒤 별도 state 3/force_cancel true 요청을 한 번 보낸다.
- 일반 보고의 force_cancel true/false 거부와 ACK·cookie·권한·속도·자동 재시도 금지 조건을 유지한다. 별도 시작의 불명확 응답도 재전송하지 않으며 학교 결과를 fresh 읽기로 분리한다.
- 합성 회귀와 공개 정적 근거를 확인했다. SDK literal은 Backend의 실제 사용자 확인/nonce/공용 임대 검증을 대신하지 않는다. 실제 학교 성공·배포·과거 실패 원인 해결은 별도 검증이다.

[명시적 시작 계약](docs/video-playback-start-contract.md)

## 0.3.30

- 영상 보고 응답의 MIME·길이·본문·JSONP·JSON·스키마·명시적 거부를 고정 분류값으로 구분한다. 기존 SchoolError 코드·직렬화·재시도 정책과 `result:true,error_code:null` 승인 조건을 유지한다.
- 진단은 package-private WeakMap에 저장하고 `inspectSchoolVideoReportResponseFailure`로 분류 enum만 읽는다. 원본 body·header·callback·URL·학교 식별자·오류 코드 값은 저장하지 않는다.
- 공개 custom script에서 확인한 `invalidpbrate`는 명시적인 false 응답의 문자열 코드가 일치할 때만 고정 분류한다. 다른 false를 동시 재생으로 추정하거나 강제 취소하지 않는다.
- 합성 회귀에서 기존 unknown 결과·controller 종료·단일 전송·UTF-8 실패의 기존 오류 코드를 확인한다. 과거 운영 실패의 원인은 이 변경으로 복원되지 않으며 실제 학교 검증·배포는 통합 담당자가 진행한다.

## 0.3.29

- 강좌의 `use_purecanvas`를 literal boolean일 때만 `usePureCanvas`로 보존한다. 레거시 false와 누락·형식 오류 null을 구분한다.
- 지원 Commons 모듈의 `content_data.item_id`를 기존 정확한 강좌·모듈 검증 뒤 `attendanceItemId`로 보존한다. 모듈 ID와 대체하지 않으며 중복 모듈 ID·다른 강좌·잘못된 ID를 거부한다.
- 같은 attendance ID의 복수 항목과 미공개 상태를 유지해 소비자가 유일성과 공개 여부를 검사할 수 있게 한다. TODO 연결·캐시·소유권·개인 완료 정책은 Backend 책임이며 조회·학교 쓰기 동작은 변경하지 않는다.
- 합성 파서 검증을 추가했다. 실제 학교 매핑·배포·화면 이동은 통합 담당자가 별도로 검증한다.

[Commons TODO 연결 계약](docs/commons-todo-link-contract.md)

## 0.3.28

- 학교 발급 `video1`의 정확한 contents29 root와 같은 콘텐츠의 CDN mobile MP4를 해석한다. 기존 contents31과 UPF는 유지한다.
- 임의 `contents숫자`·다른 콘텐츠/tenant/host·query·경로 이탈·선택 media fallback을 허용하지 않는다.
- 익명 metadata GET 두 번과 private media handle을 유지한다. 인증·소유권·진도 보고·학교 쓰기 계약은 변경하지 않는다.
- 합성 성공과 confinement 거부 회귀를 추가한다. 실제 학교 후보 검증·운영 배포·브라우저 재생 결과는 통합 담당자가 별도로 기록한다.

[해석 계약과 읽기 조사 근거](docs/video-progress-contract.md#0328--contents29-video1-저장-형식)
