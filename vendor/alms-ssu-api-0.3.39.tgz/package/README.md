# ALMS school API library

숭실대학교의 인증·학교 조회를 서버에서 연결하기 위한 TypeScript 라이브러리다. 현재 개발 중이며 MIT 라이선스를 적용한다. npm 배포 전까지 `package.json`의 `private: true`를 유지한다.

## 0.3.39 · Readystream 단일 영상 후보

정확한 `readystream`의 본문·초 단위 학교 상태를 읽고 원래 유형을 보존한다. contents31/ssu-toast의 단일 video1 UPF를 검증한 특정 private launch만 기존 수동 보고 계약에 연결한다. 발급 endat/baseline·page0·정확한 대상·관측 시간/진도 상한·재전송 금지는 유지한다. 단순 목록 marker나 본문 조회는 재생 권한이 아니며 Backend가 단일 형식 검증 뒤 capability를 결정한다. 실제 SDK .39 학교 ACK·재생 종료·출석·새 로그인·배포는 별도 QA다. [계약과 근거](docs/readystream-video-contract.md)

## 0.3.32 · 명시적 시작과 일반 진도 보고 ACK 분리

사용자가 확인한 별도 시작은 정확한 JSONP와 boolean `result:true`, own `error_code` 필드를 검증하며 `error_code` 값은 성공 조건에 사용하지 않는다. 일반 영상 진도 보고는 기존 `result:true,error_code:null` 조건을 유지한다. 시작의 false·형식 오류·유실은 재전송하지 않으며 시작 ACK 뒤에도 fresh 학교 권한과 결과를 확인한다. 시작 승인은 학습 완료·출석 인정과 별개다. 원본 정적 guard·운영 진단·합성 회귀의 범위와 실제 학교 검증 전 상태는 [시작 계약](docs/video-playback-start-contract.md#0332--명시적-시작-ack-분리)에 기록했다.

## 0.3.31 · 사용자가 확인한 별도 학교 진도 시작

`createSchoolVideoPlaybackStartController`와 `startSchoolVideoPlayback`은 일반 보고와 분리된 일회 학교 시작 동작이다. Backend가 사람의 확인·nonce·현재 본인/학교 세대·공용 임대를 검증하고, SDK는 일시정지된 native 관측·학교 발급 target/baseline·fresh 결과를 대조한다. 명시적 확인 뒤에만 별도 state 3/force_cancel true 요청을 한 번 보내며 유실·거부를 재전송하지 않는다. 기존 일반 보고의 force_cancel 차단과 실제 완료·출석 분리를 유지한다. 실제 학교 성공과 서비스 배포는 별도 검증이다. [호출 계약](docs/video-playback-start-contract.md)

## 0.3.28 · 학교 발급 contents29 영상 해석

학교가 발급한 `video1` manifest의 `contents29/ssu1000001/:contentId/contents/` 저장 형식을 추가한다. 기존 contents31과 함께 정확한 두 root만 허용하며, 선택된 desktop/html5 progressive MP4도 같은 root의 CDN `media_files/mobile` 안에 있어야 한다. 다른 번호·콘텐츠·tenant·host·query·경로 이탈을 허용하거나 다른 media 항목으로 대체하지 않는다. 기존 UPF 해석·소유권·인증·학교 보고 계약은 유지한다.

2026-10-08의 운영 읽기 조사에서 본인 신원·강좌·launch와 익명 viewer/manifest 8 GET이 모두 200이었다. 발급된 root와 선택 MP4의 콘텐츠 결합은 일치했지만 기존 resolver가 `forbidden_target`으로 거부했고 CDN 요청은 시작하지 않았다. 학교/DB/영속 jar 쓰기·보고·재생은 0이었다. 이번 파서 변경의 합성 검사와 후보 적용·학교 미디어 취득·배포·브라우저 재생은 별도 검증 단계다. [해석 계약](docs/video-progress-contract.md) · [변경 이력](CHANGELOG.md)

## 0.3.27 · 과거 학기 과제 읽기

과제 목록·상세·본인 제출 이력·안내/최근 제출 파일·이전 시도 파일은 fresh 본인 신원과 학교가 반환한 전체 학기의 수강 목록을 확인한다. 학교의 default/ended 표시로 읽기 권한을 추측하지 않고 실제 목록의 강좌·과제·본인·파일 관계를 대조한다. 전체 60초·30 GET·30학기·100강좌·JSON 2MiB/응답·8MiB 합계를 유지하며 상한 초과는 부분 성공으로 반환하지 않는다.

제출 조건·업로드/최종 제출·영수증 재확인은 기존 default 학기 소유권 검사와 학교 폼/조건 검사를 유지한다. 과거 읽기의 성공은 제출 권한을 부여하지 않는다. 이 변경은 합성 입력으로 검증하며 실제 과거 학기 학교 응답과 서비스 배포는 통합 담당자가 따로 확인한다. [읽기 계약](docs/assignment-read-contract.md)과 [이력 계약](docs/assignment-history-contract.md)을 따른다.

## 0.3.21 · 과제 제출 계약과 첨부 읽기

`LearningxClient.assignmentSubmissionOptions`, `submitAssignment`, `reconcileAssignmentSubmission`, `assignmentAttachment`를 추가했다. 새로 확인한 본인 신원·현재 수강 강좌·과제·본인 제출과 학교 발급 폼을 결합한다. 학교 동의 문구의 digest와 명시적 동의 시각, 제출 횟수와 잠금 상태를 재검증한다. 최종 쓰기는 한 번만 보내고, 응답 유실 때에는 본인 제출을 읽어 이번 내용/파일과 다음 attempt가 일치하는지 확인한다. Backend는 쓰기 전 영속 이력·실행권·현재 세션 검증과 암호화된 receipt 저장을 담당한다.

통합 담당자의 학교 읽기에서는 개인 과제의 파일 제출 폼·CSRF 쿠키·잠금/횟수 조건을 관찰했다. 업로드 초기화·파일 전송·최종 제출·첨부 파일 바이트의 실제 학교 성공은 아직 확인하지 않았다. 텍스트/URL은 해당 학교 폼이 실제로 발급될 때만 지원하며 그룹 과제와 외부 저장소 업로드는 차단한다. 합성 검사는 실제 제출 성공을 뜻하지 않는다. [계약과 남은 검증](docs/assignment-submit-contract.md)을 따른다.

## 현재 확인 범위

| 부분 | 구현·근거 | 아직 확인할 것 |
| --- | --- | --- |
| HTTP client | 학교 HTTPS host 제한, 계정별 CookieJar, 수동 redirect 검사, 크기·시간 제한, 오류 정규화 | 실제 학교 세션 만료·재로그인 응답 |
| 숭실 SSO | ALMS 운영 callback·u-SAINT 신원 검증·내부 세션 발급 확인. 0.3.1로 기존 본인 인증 자료의 LMS 교환과 대시보드 신원 검증 확인 | 0.3.1 배포 뒤 새 callback 전체 흐름, 세션 만료·갱신 |
| LearningX bootstrap | 관찰한 학교 화면의 iframe과 `#root` 속성을 파싱 | 다양한 학기·사용자·화면 변형 |
| LearningX 조회 | 본인 계정의 학기 4개·강좌 14개·강좌별 TODO 목록 14개와 두 강좌의 주차·차시·차시 출석 응답을 실제 조회·파싱 | 다른 계정·모든 강좌·활동별 제출/출석 상세, 데이터의 의미 대조 |
| u-SAINT 개인 시간표 | 본인 인증 세션으로 ECC 초기 GET·WebDynpro 읽기 초기화 POST·선택 학기와 일정 파싱을 실제 검증 | 다른 사용자·학기와 학교 화면 변경, 시간표와 LMS 강좌 ID 연결 |
| 자동수강 | 아직 이 패키지에서 구현하지 않음 | 재생 요청·실제 영상 실행·학교 진도/출석 재조회 |

합성 테스트 통과는 학교 SSO·조회·출석 성공의 증거가 아니다. 학교 계정·학생 응답·원본 HAR·강의자료는 이 저장소에 넣지 않는다. 테스트의 학번·이름·쿠키·토큰은 모두 만든 값이다.

## 로컬 검증

Node.js 24 이상을 사용한다.

```sh
npm ci
npm test
npm run typecheck
npm run build
```

CI에서도 같은 검증을 실행한다. 실제 학교 로그인이나 사용자 데이터가 필요한 테스트는 이 명령에 포함하지 않는다.

## HTTP client

```ts
import { SchoolHttpClient } from '@alms/ssu-api';

// 사용자마다 새 client를 만들고 CookieJar를 공유하지 않는다.
const client = new SchoolHttpClient();

// 학교에서 받은 해당 사용자의 쿠키가 client.jar에 준비된 후 호출한다.
const response = await client.get(
  'https://canvas.ssu.ac.kr/learningx/api/v1/learn_activities/courses?term_ids[]=1',
  { auth: 'learningx' },
);
```

위 URL의 학기 식별자는 예시다. 실제 목록·식별자는 학교 응답에서 가져온다. LearningX 인증 옵션은 canvas의 `xn_api_token` 쿠키를 `Authorization: Bearer`로 전달한다. 대상은 `canvas.ssu.ac.kr/learningx/`로 제한하며 redirect가 범위를 벗어나면 이 토큰을 header와 cookie 양쪽에서 제거한다. 쿠키가 없으면 `authentication_required`를 반환한다.

일반 GET의 허용 host는 `lms.ssu.ac.kr`, `canvas.ssu.ac.kr`, `smartid.ssu.ac.kr`, `saint.ssu.ac.kr`다. HTTPS 표준 포트만 사용한다. URL 자격정보와 외부 redirect는 거부한다. 기본 제한은 전체 요청 흐름 20초, 응답 본문 8 MiB, redirect 7회다. 세 번째 생성자 인자의 `SchoolHttpLimits`로 테스트·운영 제한을 조정할 수 있다.

개인 시간표는 추가로 `ecc.ssu.ac.kr/sap/bc/webdynpro/SAP/ZCMW2102` 경로만 허용한다. ECC의 다른 애플리케이션·비표준 포트·외부 redirect는 거부한다. ECC 전용 POST는 고정된 화면 초기화 이벤트만 생성하며 호출자가 임의 SAP 이벤트를 보낼 수 없다. 기존 SAP 세션 쿠키만 범위에 따라 사용하고 `sToken`, `sIdno`, `xn_api_token`은 ECC로 보내지 않는다.

## u-SAINT 개인 시간표

```ts
import { SchoolHttpClient, SaintTimetableClient } from '@alms/ssu-api';

// Backend가 본인임을 검증한 뒤 복호화한 해당 사용자의 jar만 사용한다.
const http = SchoolHttpClient.fromSessionJar(verifiedSchoolSession.jar);
const timetable = await new SaintTimetableClient(http).read();
```

`SaintTimetable`은 `selectedYear`, 학교 학기 키인 `selectedSemester` (`090` 1학기, `091` 여름, `092` 2학기, `093` 겨울), `entries`를 반환한다. 각 일정은 `dayOfWeek`(월요일 1–일요일 7), `courseTitle`, `startTime`/`endTime` (`HH:mm`), nullable `room`/`professor`다. 응답에 선택된 학기를 그대로 사용하며 날짜로 현재 학기를 추정하거나 사용자 선택을 바꾸지 않는다. 이 화면에서 LMS 강좌 ID를 얻을 수 없으므로 강의명만으로 자동 연결하지 않는다.

2026-10-01 본인 계정에서 GET 200 → 초기화 POST 200 → 선택 학기와 일정 파싱을 검증했다. 원문·개인정보·쿠키는 저장소에 보관하지 않았다. 학교가 여러 시간 칸에 반복한 동일 일정은 모든 필드가 같은 경우에만 중복 제거한다. 인접한 서로 다른 시간은 임의로 합치지 않는다. 빈 시간표와 누락·손상된 HTML을 구분하고, 예상하지 못한 열·시간 형식·span은 정규화 오류로 반환한다. 학교 상태를 바꾸는 수강 신청·출석·제출 이벤트는 구현하지 않는다.

프로토콜 조사는 MIT 라이선스의 [rusaint 개인 시간표](https://github.com/EATSTEAK/rusaint/blob/main/packages/rusaint/src/application/personal_course_schedule.rs)와 [wdpe 요청 구조](https://github.com/EATSTEAK/wdpe/blob/main/src/requests/reqwest.rs)를 참고했고, TypeScript 파서와 제한된 요청은 실제 응답 구조에 맞춰 독립 구현했다. HTML·XML 안의 script-call은 실행하지 않는다. 토요일·일요일·오류·중복 처리는 합성 표본으로 검증했으며 실제 확인 범위를 다른 계정이나 모든 학기로 확대해 설명하지 않는다.

## 인증을 연결할 때

- 학교 ID·비밀번호 입력은 숭실 통합로그인에서 처리한다. 이 라이브러리는 로그인 폼을 제공하지 않는다.
- `buildSchoolLoginUrl`에는 Backend 설정의 고정된 callback URL만 전달한다. 이 함수는 URL 형식만 검사하므로, 사용자 입력을 callback으로 그대로 전달해서는 안 된다.
- callback의 `sIdno`를 로그인 완료의 증거로 쓰지 않는다. `verifySchoolSso`가 서버에서 학교 portal identity를 확인하고 일치할 때만 ALMS 세션을 만든다.
- callback state/일회용 검증, 허용 출처, ALMS 세션·CSRF·CORS는 Backend가 맡는다. 이 라이브러리에는 해당 서비스 정책이 없다.
- 인증 시도별로 새 client를 만들고 실패한 시도의 CookieJar는 폐기한다. 서로 다른 사용자나 실패한 identity 검증 결과 사이에서 재사용하지 않는다.
- 응답 URL·본문·쿠키·인증 header·SSO token을 로그나 사용 분석에 보내지 않는다. `SchoolError.code`와 정규화한 상태만 기록한다.

`authentication_required`, `identity_mismatch`, `forbidden_target`, `unexpected_response`, `upstream_unavailable`, `unsupported`를 통해 오류를 구분한다. `retryable`은 재시도 가능성의 힌트이며, 학교 상태를 바꾸는 동작을 자동 재실행해도 된다는 뜻은 아니다.

0.3.11의 `SchoolSsoVerificationError`는 `SchoolError`를 확장해 현재 u-SAINT 신원 확인의 실패 단계와 필요한 경우 고정된 DOM 누락 유형만 덧붙인다. 신원 파싱 규칙·요청 순서·토큰 전달·성공 응답은 유지한다. [진단 계약](docs/sso-verification-diagnostics.md)을 따르며 이 정보 추가를 새 로그인 성공이나 기존 실패 원인 해결로 해석하지 않는다.

0.3.13은 `identity_parse` 실패에만 제한된 화면 형태 enum과 요소 존재 boolean을 추가한다. 이동 주소나 script를 보존·실행하지 않으며, 이 진단은 기존 신원 검증이나 학교 요청을 변경하지 않는다.

0.3.14의 `LearningxClient.calendar({start,end,courseId?}, signal?)`는 native 본인 신원과 현재 학기 소유 강좌를 새로 검증한 뒤 서울 날짜 범위의 일정·과제 기한을 읽는다. 소유 context 배치·명시적 페이지네이션·종일 날짜·취소·상한은 [캘린더 읽기 계약](docs/calendar-read-contract.md)을 따른다. 개인 일정 쓰기나 제출·출석 상태 변경은 수행하지 않는다.

`LearningxClient.assignments(courseId, signal?)`와 `assignmentDetail(courseId, assignmentId, signal?)`는 소유 강좌의 전체 과제 목록·상세·본인 제출 결과를 읽는다. [과제 읽기 계약](docs/assignment-read-contract.md)에 따라 미제공/명시적 null/미공개/이전 평가를 구분하고, 현재 공개 조건을 확인한 점수만 제공한다. 첨부는 메타 정보만 반환하며 모듈 ID를 추측하지 않는다. 제출·응시·다운로드·읽음 표시를 실행하지 않는다.

`LearningxClient.moduleLearningStatus(courseId, moduleItemId, signal?)`는 본인 신원·현재 선택 학기 소유 강좌·모듈과 활동을 매번 다시 확인하고 캐시 없이 학습 상태를 읽는다. [학습 상태 읽기 계약](docs/learning-status-read-contract.md)에 따라 전체 취소·시간·응답 상한을 적용한다. 완료·진도와 출석 비대상을 구분하며, 학교의 명시적 인정 계약이 확인되지 않았으므로 `recognized`는 항상 `null`이다. 재생·진도 보고·학교 쓰기·작업 상태 변경은 수행하지 않는다.

## 테스트 범위

### 영상 callback 대상 결합

`prepareSchoolVideoCallbackBinding(source, userLogin)`은 `parseSchoolVideoLaunch`가 소유 모듈·상세에 결합한 opaque launch를 입력으로 받는 서버 전용 순수 파서다. 호출자는 기존 `moduleLearningStatus`의 native 본인·현재 학기 수강권한·모듈·상세 검사와 현재 학교 인증 generation 검사를 생략하면 안 된다. `userLogin`은 native 본인 신원과 대조한 LearningX bootstrap의 login이며 native Canvas 숫자 ID를 대신 넣지 않는다.

바깥 Commons viewer와 안쪽 `TargetUrl`을 분리해 해석한다. 정확한 Canvas progress 경로의 course/component는 launch의 실제 강좌와 attendance item에, query의 `user_id`, `content_id`, `content_type=movie`는 본인 login·동일 콘텐츠·영상 유형에 대조한다. component는 모듈 item ID가 아니다. 누락·중복·알 수 없는 query, 추가 디코딩이 필요한 입력, 다른 host·userinfo·fragment·비정규 경로는 거부한다.

section의 출처는 **그 소유 활동의 학교발급 callback 경로 자체**다. 2026-10-03 읽기 전용 7 GET 조사에서 별도의 section 대응 필드를 찾지 못했다. 이를 0으로 채우거나 다른 module/주차 필드와 같다고 추정하지 않는다. 학교가 발급한 0 또는 정규 양수 경로를 그대로 보존하며, 다른 값으로 URL을 재구성하지 않는다. 실제 표본은 0 경로 한 개이고 양수 처리는 합성 회귀로 검사했다. summary의 `sectionSource:'issued_callback'`은 독립 분반 필드와 대조했다는 뜻이 아니다.

반환 handle과 `inspectSchoolVideoCallbackBinding()`의 고정 summary는 URL·학생 식별자·콘텐츠 ID를 노출하지 않는다. 원래 주소는 WeakMap 내부에만 있고 공개 accessor가 없다. 이 파서는 HTTP를 요청하거나 player·media·보고를 실행하지 않는다. `targetBound:true`는 위의 대상 결합이며 fresh 조회 자체의 완료나 보고 허가가 아니다. `reportingVerified:false`와 기존 launch/media의 `callbackVerified:false`를 유지한다. wire method·진도 필드·응답 의미, 실제 서버 재생과 출석 인정은 각각 별도 게이트다.

테스트는 URL allowlist·redirect 제한과 취소, host별 cookie 격리·만료, 401/403 및 HTTP 200 로그인 HTML, SSO 성공 script 구분, 응답 byte 제한·읽기 실패·timeout, LearningX token의 host/path 제한, callback identity 불일치, LearningX의 합성 parser 입력을 다룬다. 실제 학교 API를 호출하거나 출석·제출 상태를 바꾸지 않는다.

공개 npm 배포·실제 학교 연동 완료 표시는 별도 검토 후 진행한다.

## 학교 조회 어댑터

Backend가 해당 사용자의 인증된 세션을 복호화한 뒤 `SchoolHttpClient.fromSessionJar(session.jar)`로 쿠키를 복원한다. 새 CookieJar를 생성하므로 복원한 client끼리 변경을 공유하지 않는다. 외부 요청 본문으로 받은 jar를 복원하거나 복호화한 상태를 로그로 남기지 않는다. 갱신한 jar의 암호화·저장은 Backend 책임이다.

`initializeLearningxClient(http, verifiedStudentId)`는 기존 LMS 세션으로 `/mypage`와 학교가 반환한 LearningX iframe을 읽고, `#root`의 사용자 식별자·학습자 역할을 확인한다. u-SAINT 인증만으로 LMS 인증이 된다고 가정하지 않는다. 실제로 관찰한 LMS 로그인 경로로 돌아오면 `authentication_required`를 반환한다.

`LearningxClient`의 조회 계약은 다음과 같다. 아래 추가 파서는 학교가 제공한 정적 JavaScript의 소비 필드를 근거로 작성했으며, 합성 표본 검증과 인증된 실제 JSON 검증을 구분한다.

| 메서드·파서 | 반환 범위 | 의미와 제한 |
| --- | --- | --- |
| `terms()` | `SchoolTerm[]` | 학교 경로로 제한한 `API_V1_ENDPOINT` 선언을 사용. 선언이 없는 실제 대시보드에서는 실측한 고정 `/learningx/api/v1/users/{userLogin}/terms` 경로 사용 |
| `selectDefaultTerms(terms)` | `SchoolTerm[]` | 학교 `default === true` 항목을 서버 순서대로 선택. 없으면 학교 대시보드와 같이 배열 첫 항목을 선택. 연도·이름 추정이나 학교 브라우저 저장값 접근은 하지 않음 |
| `courses(termIds)` | `SchoolCourse[]` | 선택한 학기의 강좌 |
| `modules(courseId)` | `SchoolModule[]` | 주차와 혼합 활동. 최상위·중첩 유형, 기한·공개 여부·판정 가능한 완료 여부를 최소 반환. 현재 주차·진도·출석을 추정하지 않음 |
| `todos(termIds)` | `SchoolCourseTodos[]` | 학생 대시보드의 할 일 목록. 전체 과제 목록이나 제출 완료 기록이 아님. 기한은 학교의 `due_date` 원문이며 누락 시 `null` |
| `lessons(courseId)` | `SchoolLessonWeek[]` | 학교의 차시 일정. 시간표 전체나 차시 출석과 다름 |
| `lessonAttendances(courseId)` | `SchoolLessonAttendance[]` | 차시 단위 학교 상태와 계산 유형. 활동 단위 결과에서 재계산하지 않음 |
| `parseAttendanceItems` / `parseAttendanceSummaries` | 활동 목록 / 항목별 학교 상태 | 파서만 제공. 출석 화면에서 `API_V1_ENDPOINT`를 확인하기 전에는 네트워크 메서드를 제공하지 않음 |

`attendance_status`는 학교 원문을 보존하고 누락 시 `null`이다. 알려진 값은 `attendance`, `late`, `absent`, `none`, `excused`이며 새로운 값도 임의 변환하지 않는다. 교사용 수치 집계는 학생의 출석 상태로 사용하지 않는다. 활동 유형별 `counts`, 시청 시간이나 진도율을 출석 완료로 해석하지 않는다. 새 TODO·출석 파서의 `sourceUrl`은 대상 확인 전까지 `null`이다.

0.3.29부터 강좌는 literal `use_purecanvas`를 `usePureCanvas: boolean | null`로, 지원 Commons 모듈은 검증한 `content_data.item_id`를 `attendanceItemId?: string`로 보존한다. 이 메타정보만으로 TODO를 연결하지 않는다. 같은 사용자·강좌·학교 인증의 정확한 유형·단일 항목·공개 여부 확인과 캐시는 소비자 책임이다. [Commons TODO 연결 계약](docs/commons-todo-link-contract.md)을 따른다.

근거는 학교 화면이 참조한 `Dashboard/dashboard-view.app.js`, `LectureAttendance/course-menu.app.js`, `commons.js`의 버전 `4.82.9`다. Dashboard의 `getStudentTodosByTermId`와 학생 TODO 렌더링은 `/learningx/api/v1/learn_activities/to_dos`, `to_dos[].course_id/activities/todo_list`, 항목의 `title/component_type/due_date`를 사용한다. commons의 출석 모듈은 `/lessons`, `/lessons/attendances`와 항목별 요약을 별도로 읽는다. 원본 학교 응답이나 정적 JS 번들 자체는 저장소에 포함하지 않는다.

### 새 callback의 LMS 인증 교환

`prepareLmsSso(http)`를 먼저 호출하고, **같은** `SchoolHttpClient`에 `exchangeLmsSso(http, {sToken, sIdno}, {tokenFormat: 'api_callback'})`를 호출한다. 준비 단계는 `/mypage`에서 학교가 제시하는 redirect를 따라가며 LMS의 host-only 로그인 준비 쿠키를 유지한다. 최종 `/xn-sso/login.php`의 공식 SmartID 링크와 `xn_sso_uniqid_for_this_login`, `xn_sso_csrf_token_for_this_login` 쿠키를 확인한다. 새로운 SmartID callback을 받으면 준비 다음에 LMS 인증을 한 번 시도한다. 인증 교환 순서는 LMS의 `/xn-sso/gw-cb.php` GET → 해당 응답이 제시한 Canvas iframe GET → 학교가 발급한 암호화 인증 자료의 메모리 복호화 → 정확한 `https://canvas.ssu.ac.kr/login/canvas` form POST → 사용자별 LMS bootstrap 확인이다. 사용자에게 학교 비밀번호를 받는 기능은 없다. 학교의 literal URL·암호화 호출만 파싱하고 JavaScript를 실행하지 않는다. 임의 form action·추가 POST 필드를 받지 않으며 Canvas 인증 POST의 307/308 redirect에는 자료를 재전송하지 않는다.

이 순서는 [참고 프로젝트의 인증 흐름](https://github.com/chlwhdtn03/LMS-API/blob/main/library/src/commonMain/kotlin/io/github/chlwhdtn03/internal/LmsAuthService.kt)과 [RSA 처리 방식](https://github.com/chlwhdtn03/LMS-API/blob/main/library/src/jvmMain/kotlin/io/github/chlwhdtn03/LmsApi.android.kt)을 읽고 독립 구현했다. 준비 과정에서 얻는 쿠키는 같은 서버 측 사용자 jar에 보존하고 SmartID 브라우저 쿠키로 복사하지 않는다. 학교 비밀번호 입력은 공식 통합로그인에서만 이루어진다. 기존 artifact 재사용 검사는 LMS 인증 실패로 끝났으며, 만료·1회성·수신 대상 제약 중 원인은 아직 확정하지 않았다. 합성 테스트 성공을 실제 fresh 교환 성공으로 표시하지 않는다.

참고 구현은 SmartID POST 응답 **본문**에서 토큰을 추출할 때 escape를 변환하며, `Set-Cookie`의 토큰으로 대신하는 경로에는 그 변환이 없다. ALMS의 `apiReturnUrl` callback에도 같은 변환이 필요하다는 근거는 없다. 0.2.2는 기본 `api_callback` 입력을 그대로 URLSearchParams에 넣으며 percent decode나 x 변환을 추가로 하지 않는다. 본문에서 추출한 입력을 지원할 때만 명시적인 `html_escaped` 옵션으로 단일 pass x 변환을 한다. 실패 후 다른 표현으로 자동 재시도하지 않는다.

2026-10-01 공개 진입 실측에서 `/mypage` → `/xn-sso/gw.php` → `/xn-sso/login.php`와 준비 쿠키 발급을 확인했고, 새 `prepareLmsSso`도 정상 TLS의 실제 공개 응답으로 통과했다. 개인정보·토큰·원본 HTML은 저장하지 않았다. 준비 쿠키가 인증서 검증에 필수인지, API callback 원형 전달과 이 준비 과정으로 실제 LMS 로그인까지 성공하는지는 아직 미검증이다. 기존 실패의 원인이 해결됐다는 뜻은 아니다.

0.3.1은 인증서 GET에 query와 같은 `sToken`, `sIdno` 값을 일회성 Cookie header로도 전달한다. 대상은 최초 `https://lms.ssu.ac.kr/xn-sso/gw-cb.php` 요청 한 번이며 jar에 추가하지 않는다. 기존 jar의 동명 쿠키는 이 요청 흐름에서 제외한다. redirect에서는 일회성 쿠키를 제거하고, 인증 자료를 query에 포함한 redirect는 거부한다. callback 값에 percent decode나 x 변환을 추가하지 않으며 Cookie 구분자·공백·제어문자·비ASCII 값은 오류로 처리한다.

이 변경은 MIT 라이선스 [ssuMCP의 인증서 요청](https://github.com/ghdtjdwn/ssuMCP/blob/2cfe542eac85864a30b9379b15fa5e4c31505a71/src/main/java/com/ssuai/domain/auth/lms/LmsSsoService.java#L128-L145)의 프로토콜과, 본인 계정의 제한된 실측에서 해당 쿠키 추가 후 LMS가 인증서 거부 페이지 대신 인증 callback과 Canvas iframe을 반환한 결과를 근거로 독립 구현했다. 참고 코드의 로그·쿠키 저장 정책은 복사하지 않았다. 쿠키가 빠진 요청은 앞선 실측에서 거부됐지만 이 관찰만으로 모든 계정·세션의 원인을 일반화하지 않는다.

0.3.1은 학교가 제시한 `/learningx/login/from_cc` frame에서 `xn_api_token` 쿠키를 받으면 RSA form을 생략했다. 0.3.3은 form이나 `loginCryption` 흔적이 있으면 토큰 유무와 관계없이 학교 발급 RSA form을 엄격하게 검증하고 Canvas 인증을 마친 뒤 bootstrap을 수행한다. 해당 흔적이 없는 토큰 응답만 기존 LearningX 경로로 처리한다. 두 경로 모두 학교 대시보드의 신원과 예상 학번이 일치해야 한다. 학교 스크립트 실행·비밀번호 수집·자동 재시도는 추가하지 않는다.

0.3.6은 정확한 Canvas POST 로그인 form 또는 `window.loginCryption` 호출이 있을 때만 native 인증 파싱을 요구한다. 일반 검색 form처럼 무관한 form만 있는 응답은 LearningX token과 대시보드 신원을 검증하는 경로로 처리한다. 정확한 form만 있거나 호출만 있는 불완전한 인증 응답은 계속 실패하며, token으로 우회하지 않는다. 호출의 `window`·`.`·`loginCryption` 사이 공백은 진단과 파서에서 동일하게 허용한다. JavaScript 실행이나 동적 인수 평가는 하지 않는다. 준비 옵션의 기본값도 바꾸지 않는다.

LearningX client 반환은 LearningX 신원 확인을 뜻한다. 이 경로에서 native Canvas 쿠키가 없으면 `onCanvasFrame.canvasSessionCookiePresent`는 `false`로 남는다. 이를 native Canvas 이용 가능이나 과제 조회 성공으로 표시하면 안 된다. `onCanvasFrame`은 인증 **전** 관찰값이므로, `true`라도 실제 native 신원 조회 성공을 증명하지 않는다.

`parseCanvasIssuedLogin`의 `CanvasIssuedLoginError.reason`과 교환 오류의 `LmsExchangeError.canvasParseReason`은 값 없는 실패 분류다. 기존 `code`, `message`, `stage`는 유지하며 파서 외 단계에는 `canvasParseReason`을 넣지 않는다.

| reason | 의미 |
| --- | --- |
| `form_target` | 허용되지 않은 응답·form 대상 또는 입력 식별자 형식 |
| `form_count` | 정확한 Canvas POST form이 없거나 여러 개 |
| `csrf_shape` | 허용되지 않는 CSRF 누락, 빈 값·중복·길이 또는 사용자 필드 중복 |
| `identity_mismatch` | form의 사용자 값과 예상 신원 불일치; 기존 동명 오류 코드 유지 |
| `issued_payload_count` | 두 literal 인수를 가진 발급 호출이 없거나 여러 개 |
| `issued_payload_format` | literal escape 또는 암호문 형식·길이 오류 |
| `key_format` | 개인키 형식·길이 또는 RSA 키 유형 오류 |
| `decrypt_failed` | 복호화 연산 실패 |
| `decoded_value_invalid` | UTF-8 변환, 비어 있는 값, 길이 또는 제어문자 검증 실패 |

원문·URL·CSRF·암호문·키·복호화 결과·내부 오류 원인(`cause`)은 진단에 포함하지 않는다. Backend가 보존하려면 이 enum만 별도로 허용하고 암호화된 진단에 저장해야 한다. 기존 소비자가 새 필드를 자동 보존한다고 가정하지 않는다. 0.3.6은 합성 응답으로 검증한 파서 보완이며 실제 학교 native 인증 성공을 뜻하지 않는다.

`prepareLmsSso(http, {canvasLogin: true})`는 학교 Canvas 로그인 안내 화면에서 관찰한 고정 링크 `/xn-sso/gw.php?from=web_redirect&cvs_lgn=true`로 진입한다. 최종 `/xn-sso/login.php`의 `cvs_lgn=true`, 기존 공식 SmartID 링크와 준비 쿠키를 확인한다. 옵션을 생략하거나 `false`로 설정하면 기존 `/mypage` 진입을 유지하며 다른 값은 요청 전에 거부한다. **준비 성공이나 LearningX 인증 성공은 native Canvas `/api/v1/` 인증 성공의 증거가 아니다.** 새 학교 로그인 후 별도로 확인해야 한다.

`exchangeLmsSso`의 선택적 `onCanvasFrame` 콜백은 처음 받은 Canvas frame의 HTTP 상태, form·iframe·inline script 개수(최대 10,000), 로그인 코드·정확한 Canvas POST form·범위에 맞는 토큰 및 `_normandy_session` 쿠키 존재 여부만 전달한다. 공개 타입은 `LmsCanvasFrameEvidence`다. 0.3.8은 선택 필드 `canvasCsrfFieldState`에 `absent`, `present`, `empty`, `multiple`, `unknown` 중 하나를 추가한다. 정확한 POST form이 하나가 아니면 `unknown`이다. 원문·URL·필드/쿠키 값·식별자는 포함하지 않는다. frame 요청 실패 시 호출하지 않고, 성공하면 인증 분기 전에 최대 한 번 호출한다. 동기·비동기 콜백 예외는 인증 결과를 바꾸지 않는다. Backend는 필요한 필드만 암호화한 학교 세션 진단으로 보존하고 공개 응답·로그·분석 이벤트로 보내지 않는다.

### 0.3.8: 발급 로그인 폼의 CSRF 필드 생략

학교가 발급한 `/learningx/login/from_cc` 응답에서 정확한 Canvas POST form과 RSA 발급 자료를 검증한 경우에만 `authenticity_token` 필드의 완전한 부재를 허용한다. `CanvasLoginFields.authenticityToken`은 그 경우 `null`이고 POST에서 해당 키를 생략한다. 존재하지만 비어 있는 값, 공백만 있는 값, 중복·초과 길이 또는 사용자 필드 중복은 계속 거부한다. 일반 `/login/canvas` 페이지의 필드 누락은 허용하지 않는다. 신원 불일치·발급 자료 누락·복호화 실패도 그대로 오류다.

근거는 실제 저장 진단 `canvas_form / csrf_shape`와 [공개 참고 구현의 선택 필드 처리](https://github.com/chlwhdtn03/LMS-API/blob/34c5d9d1e12717b1e0dd8a2745634ce95b270ff9/library/src/commonMain/kotlin/io/github/chlwhdtn03/internal/LmsAuthService.kt#L74-L86)다. 실제 진단만으로 필드가 누락됐는지, 빈 값이었는지까지 확정하지 않았다. 기존 callback 재사용은 학교 인증 거부로 끝나 중단했으며 새 발급 폼의 구조와 native Canvas 신원은 정상 로그인 후 별도로 확인한다. [세부 계약과 검증 범위](docs/canvas-issued-auth.md)를 따른다.

0.3.3에는 과제 본문·본인 제출 내역의 전용 조회 API를 아직 추가하지 않았다. 모듈 목록이나 완료 표시를 실제 제출 상태로 간주하지 않는다.

2026-10-01 본인 계정의 기존 학교 인증 자료로 0.3.1의 인증서 GET 302 → from_cc GET 200 → LMS 대시보드 신원 검증을 통과했다. 새 callback을 받은 검증은 아니며 다른 계정의 성공을 보장하지 않는다. 해당 대시보드는 inline `API_V1_ENDPOINT` 선언을 생략했지만 고정 학기 조회 URL은 실제 JSON 200을 반환했다. 선언 부재만으로 조회를 막던 조건을 제거하고 기존 Bearer 전달 범위와 JSON 파서를 유지한다.

동일하게 검증한 세션에서 학기 4개, 강좌 14개, 강좌별 TODO 목록 14개를 읽었다. 선택한 두 강좌는 각각 주차 15개·차시 주차 15개와 차시 출석 목록 5개/4개가 기존 파서를 통과했다. 과제 제출 완료·각 활동의 출석 의미·전체 강좌의 모든 응답까지 확인한 것은 아니다. 원본 응답 대신 상태·필드 종류·개수만 기록했고 저장소 테스트는 합성 표본을 유지한다.

실측한 주차 항목의 `content_type`에는 `attendance_item`, `assignment`, `sub_header`가 있으며, `content_data.item_content_type`에는 `commons`, `video_conference`가 있다. `itemContentType`과 `resourceType`은 각각 이 중첩 유형과 `item_content_data.content_type`만 반환한다. 본인 응답에서 resource 유형 `pdf`, `movie`, `file`을 확인했으며 새 유형도 임의로 영상·자료로 바꾸지 않는다. `completed`는 `completion_determinable === true`이고 원래 값이 boolean일 때만 제공하며, 학교 출석·제출 완료로 변환하지 않는다. `dueAt`·`unlockAt`은 시간대가 있는 유효한 ISO 일시만 원문 그대로 반환하고 다른 형식은 `null`이다. `published`는 최상위 boolean을 우선하고 없으면 중첩 boolean을 사용한다. 중첩 `course_id`가 제공됐는데 요청 강좌와 다르면 오류로 처리한다. 화상수업의 회의 키·비밀번호·참여자 정보와 임의 URL·본문은 반환하지 않는다.

Backend는 LMS 교환 다음에 `verifySchoolSso`로 u-SAINT 신원을 독립 검증한다. 어느 단계든 `identity_mismatch`가 발생하면 전체 인증을 거부한다. 그 외 LMS 실패를 선택 기능의 정규화된 진단으로 남길지는 Backend 정책이며, u-SAINT 검증을 생략할 수 없다. `LmsExchangeError`의 `stage`는 `preparation`, `certificate`, `canvas_frame`, `canvas_form`, `canvas_submit`, `bootstrap` 중 하나이고 `code/message`는 기존 `SchoolError` 코드만 담는다. URL·form·RSA 키·복호화 값은 기록하지 않는다.

0.2.1의 `LmsExchangeError.certificateEvidence`는 선택적인 비식별 진단이다. Backend가 보존할 때도 아래 필드만 골라 암호화된 학교 세션 메타데이터에 넣고, 공개 API·로그·분석 이벤트로 보내지 않는다.

| 필드 | 허용 값 |
| --- | --- |
| `reason` | `request_failed`, `school_rejection_page`, `missing_frame`, `multiple_frames`, `invalid_frame` |
| `httpStatus` | 정수 100–599 또는 `null` |
| `finalOrigin` | `lms`, `canvas`, `smartid`, `saint`, `other`, `unknown` |
| `iframeCount`, `scriptCount`, `formCount`, `frameCandidateCount` | 0–10,000의 정수 또는 `null` |
| `hasSchoolRejectionText` | boolean 또는 `null` |

0.3.4는 inline script가 있는 인증서 실패 응답에 선택적 `scriptNavigation`을 추가한다. `locationAssignmentPresent`는 위치 대입/assign/replace 구문의 존재, `literalRedirectCount`는 최대 10,000개의 literal 후보 수다. `literalRedirectOrigin`은 `none/lms/canvas/smartid/saint/other/multiple/unknown`, `literalRedirectPath`는 `none/lms_gateway/lms_login/lms_callback/lms_home/canvas_from_cc/canvas_login/canvas_dashboard/canvas_callback/other/multiple/unknown` 중 하나다. URL·query·본문은 포함하지 않는다. 동적 식이나 script는 실행하지 않고 이 후보로 이동하지 않는다. script 안의 후보 존재는 인증 성공이나 실제 redirect 실행의 증거가 아니다.

관찰한 `인증에 실패` 문구와 iframe·script·form·후보가 모두 없는 구조만 `school_rejection_page` / `authentication_required`로 분류한다. 구조가 없거나 여러 후보가 있으면 `unexpected_response`다. 전송 계층이 응답을 반환하기 전에 실패하면 상태·출처·본문 구조를 추정하지 않고 `request_failed`와 `null`/`unknown`을 남긴다. 이 경우 원래 정규화한 오류 코드는 유지한다. 오류에 실제 URL·본문·토큰·식별자를 포함하지 않는다.

## 라이선스

[MIT 라이선스](LICENSE)를 적용한다. 이 라이브러리를 수정하거나 비공개 프로젝트·상용 서비스에서 사용할 수 있으며, 파생 코드나 서비스의 소스 공개 의무는 없다. 라이브러리의 사본 또는 상당 부분을 포함할 때는 저작권 표시와 MIT 허가 문구를 유지해야 한다. 상세 조건은 [Open Source Initiative의 MIT 원문](https://opensource.org/license/mit)과 `LICENSE`를 따른다.

이 라이선스는 이 라이브러리 코드에 적용한다. 의존 패키지와 제3자 자료의 라이선스·저작권 고지는 각각 유지하며, 학교 데이터·강의자료나 ALMS Front·Backend의 이용·공개 조건을 변경하지 않는다. 라이선스 적용과 GitHub 저장소 공개·npm 배포는 별개다.

## Owned module activity details (0.3.2)

`client.moduleActivityDetail(courseId, moduleItemId)` re-reads modules and binds the selected module to the actual attendance-item ID before fetching Commons video/PDF/file metadata. The caller must first verify course ownership. The result contains text-only description, nullable school metadata and an exact query-free material viewer URL. It never returns the student-specific `viewer_url` progress callback. Assignment detail and playback are still unsupported by this method.

### 영상 진도 단위와 서버 전용 launch 후보

학교의 실제 배포 `commons.js?version=4.82.9` 영상 컴포넌트에서 `duration`·`progress`는 초 단위로 표시하며, 비율은 `progress / duration * 100`으로 계산하는 것을 확인했다. 출석 로그의 `last_at`도 초 단위로 표시한다. `movie` 상세는 `durationSeconds`와 `attendance.progressSeconds`, `attendance.lastPositionSeconds`, `attendance.progressPercent`를 추가 제공한다. 기존 `*Value` 필드는 유지한다. `progressPercent`는 유효한 양수 duration이 있을 때 0–100 범위로 제한하며, 누락·잘못된 값과 자료/PDF는 `null`이다. 출석 완료·인정은 이 비율로 계산하지 않고 원래 `completed`·`status`를 유지한다. [학교 정적 소스](https://canvas.ssu.ac.kr/learningx/js/commons.js?version=4.82.9) · [계약과 검증 범위](docs/video-progress-contract.md)

`client.moduleActivityVideoLaunch(courseId, moduleItemId)`는 서버 전용 opaque 후보를 반환한다. 모듈→실제 상세 ID를 다시 대조하며 `movie`, `published === true`, `opened === true`, 콘텐츠 ID에 맞는 정확한 Commons HTTPS `/em/:contentId` 주소만 보관한다. 이 메서드는 Commons나 media/callback을 요청하지 않는다. 일반 JSON·inspection은 원본 주소를 내보내지 않으며 서버 loader만 `inspectSchoolVideoLaunch(candidate)`로 메모리 안의 원문을 읽을 수 있다. accessor 결과는 공개 DTO·로그·DB에 넣지 않는다. `callbackVerified:false`는 callback 실행 계약을 아직 검증하지 않았음을 뜻한다. 후보 생성 성공을 재생 가용성이나 학교 인정으로 바꾸지 않는다. 학교 원문 query를 제거하거나 다시 조립하지 않는다.

### 수동 MP4 해석 (0.3.24)

`resolveSchoolVideoMedia(launch, http?, {signal}?)`는 학교의 출석 설정이 명시적 boolean인 영상에 대해 관찰한 Commons HTML/XML 구조를 읽고 `SchoolVideoMedia` 핸들을 반환한다. `inspectSchoolVideoMedia(media)`는 서버만 사용할 원본 주소와 metadata를 제공하며 `useAttendance`를 학교 값 그대로 유지한다. 호출자는 소유권·현재 세션·공개/열림 상태를 검증한 고정 서비스 경로로 브라우저에 미디어를 전달해야 한다. resolver는 metadata GET 두 번만 수행하고 미디어·진도 요청이나 스크립트 실행은 수행하지 않는다.

0.3.5에서는 실제 비출석 참고 영상의 원본 해석, 별도 HEAD 200과 1바이트 Range 206을 확인했다. 0.3.17은 출석 대상 영상도 같은 원본 해석 경로에 허용하지만 학교 진도·출석을 반영하지 않는다. 서비스는 이 제한을 재생 화면에 명시해야 하며 `callbackVerified:false`를 유지한다. 미확인 출석 설정·HLS·다중 story·다른 저장소 구조는 계속 지원하지 않는다. 이번 확대의 합성 검사와 이후 학교 실측을 구분한다. [지원 범위와 HTTP 제한](docs/video-progress-contract.md)

0.3.24는 학교에서 관찰한 `upf` manifest의 단일 `video1` story와 단일 MP4만 추가 해석한다. 기본 media ID와 선택된 media ID, 상세·content·story의 duration, 소유 콘텐츠의 `contents15/ssu1000001` 주소를 대조한다. 발급된 `service_root`의 all/mobile progressive template이 같은 정확한 CDN 경로를 가리킬 때 `[MEDIA_FILE]` 한 개를 선택된 basename으로 바꾼다. pseudo/flash-fallback은 사용하지 않으며 임의 파일 경로·첫 배열 항목·다중 story로 대체하지 않는다. 기존 `video1`의 contents31/mobile 경로는 유지한다.

새 해석도 익명 metadata GET 두 번만 수행한다. 추가 UPF 파일·media 바이트·학교 보고를 요청하지 않으며 generic HTTP 인증·host·redirect·시간·응답 크기 제한을 바꾸지 않는다. 합성 검사는 실제 미디어 재생이나 학교 진도·출석 반영의 근거가 아니다.

## PDF 열람 기록

0.3.7의 `acknowledgeMaterialView()`는 실제 표시한 PDF 쪽만 학교 보고 규격에 맞춰 전달한다. 캐시·선행 다운로드는 보고를 일으키지 않는다. [계약과 실제 검증 경계](docs/material-view-contract.md)를 따르고, `recorded`를 학교 완료나 출석 인정으로 바꾸지 않는다.

0.3.9는 알려진 학교 실패에 `SchoolMaterialViewError`의 고정 `stage`(`validation`, `callback`, `refresh`)를 추가한다. 기존 오류 코드·재시도 가능 값과 학교 요청 순서는 유지한다. `beforeWrite`의 호출자 예외는 그대로 전달하며 원문·URL·식별자·원래 예외의 `cause`를 진단에 보관하지 않는다. 단계 진단은 운영 오류의 원인 확정이나 자동 재시도 허용을 뜻하지 않는다.

0.3.10은 새 학교 상세에서 이미 완료된 PDF를 확인하면 `report:'already_completed'`와 그 상세를 반환한다. 이 경우 manifest·`beforeWrite`·학교 보고는 실행하지 않으며, Backend는 반환 직전에 현재 세션을 다시 확인해야 한다. false·null인 완료 값은 기존 보고 검증을 모두 거친다. 기한으로 완료를 추정하거나 누락된 학교 callback을 만들지 않는다.

## 강의계획서 렌더러 계약 · 미출시

0.3.18은 학교 발급 일반형·공학형(KONG) 두 보고서만 지원한다. launcher부터 ODI 설정·인증 요청까지 발급 보고서명이 일치해야 하며 다른 변형은 거절한다. 기존 일반형만 허용하던 파서의 공학형 `unsupported` 오류를 수정했다. 합성 검사와 실제 PDF 취득·운영 배포 검증은 구분한다.

`prepareCourseSyllabusRender()`는 소유 강좌·SIS·학교 발급 launcher를 새로 검증한 서버 전용 핸들을 제공한다. 실제 인증 확인은 같은 HTTP client의 `readSyllabusRenderAuthCheck()`로 한 번 수행하고, 검증된 학교 응답을 뷰어에 전달한다. `parseSchoolSyllabusPdf()`는 단일 메모리 출력·크기·인코딩을 검사하고 호출자가 주입한 실제 PDF 구조 검사까지 통과해야 바이트를 반환한다. 발급 URL·HTML·파일명·문서 바이트는 JSON이나 진단에 포함하지 않는다. 현재 합성 검사만 완료했으며 학교 PDF 취득과 서비스 내부 제공은 별도 실측이 필요하다. [렌더러·PDF 계약](docs/syllabus-document-contract.md)

### 학교 `mp4` 영상 유형 호환

0.3.23은 주차 모듈 목록에서도 정확한 `attendance_item/commons/mp4`를 공개 `resourceType: movie`로 표시하고, 소유 강좌·항목 ID가 있는 경우 상세 열기를 제공한다. 앞선 상세·학습 상태 호환만으로는 목록이 일반 학습 활동으로 남던 누락을 수정했다. 원본 private launch·callback의 mp4 유형은 유지하며 다른 별칭은 추가하지 않는다. 이 목록 수정의 합성 검사와 실제 화면·재생 검증은 구분한다.

학교 모듈과 상세의 정확한 `mp4` 유형도 영상으로 읽는다. 공개 상세·학습 상태의 `resourceType`은 기존 `movie`와 동일하게 초 단위 영상 정보로 제공하지만, private launch의 `contentType`과 발급 callback의 `content_type=mp4`는 그대로 보존한다. 모듈과 상세의 원본 유형이 다르거나 movie/mp4 callback이 섞이면 거부한다. 임의 video 별칭·MIME 문자열·대문자 변형은 허용하지 않는다.

소유 강좌의 실제 모듈·상세·발급 callback에서 mp4 대응을 읽기 전용으로 확인했다. 이 수정은 진도 요청을 보내지 않으며 실제 SDK 미디어 해석·재생·진도/출석 반영 검증을 대신하지 않는다.

## 영상 보고 후보 · 0.3.22

학교가 발급한 callback 대상과 실제 재생 관측을 결합하는 controller 및 1회 GET JSONP transport를 추가했다. 원본 학교 플레이어 요청 전달과 ALMS 수동 video 관측 adapter를 구분한다. 수동 adapter는 학교 발급 초기 진도와 fresh 상세의 일치를 요구하고, 서버 경과시간·연속 위치·1배속·가시성을 검사한다. 누적값을 클라이언트에서 받거나 재생 시간 합으로 만들어 보내지 않는다.

`createSchoolVideoReportController` / `forwardSchoolVideoPlayerRequest`는 원본 runtime용이고, `createSchoolManualVideoReportController` / `observeSchoolManualVideoPlayback` / `reportSchoolManualVideoPlayback`는 수동 재생용이다. Backend의 세션·generation·nonce·공용 실행 lease·fresh 권한 검증이 선행 조건이다. 응답 유실은 fresh 학교 재조회 후 controller를 닫으며 자동 재시도나 force_cancel을 하지 않는다. ACK를 출석 인정으로 바꾸지 않는다. 합성 검사는 실제 SDK 전송·배포 성공을 대신하지 않는다. [규격·책임·검증 범위](docs/video-progress-contract.md)를 따른다.

0.3.37의 수동 handle은 `observationTiming:'client_monotonic_v1'` 지원을 명시한다. Backend가 설치 SDK와 실제 준비한 handle을 확인해 이 모드를 협상한 경우에만 같은 media snapshot의 `performance.now()`를 `capturedAtMs`로 보낸다. 타이밍 없는 기존 호출은 기존 서버 시간 검사를 유지한다. [정확한 시간 한도·오류 진단·위조와 지연 구분의 한계](docs/video-progress-contract.md#0337--수동-관측의-선택적-monotonic-타이밍)를 함께 적용한다.
